local addonName, EL = ...

local ticker
local PANEL_MIN_W, PANEL_MIN_H = 352, 190
local SESSION_EXPANDED_H, SESSION_COLLAPSED_H = 166, 36
local ACTION_BAR_H = 36
local SESSION_VISIBLE_ITEM_ROWS, SESSION_ITEM_ROW_H = 4, 18
local PANEL_DEFAULT_VISIBLE_ROWS = 12
local PANEL_EXPANDED_MIN_H = 300
local PANEL_MAX_W, PANEL_MAX_H = 900, 720
local PANEL_MIN_SCALE, PANEL_MAX_SCALE = 0.6, 1.4
local BUTTON_ICON = "Interface\\Icons\\INV_Enchant_EssenceCosmicGreater"
local READY_ICON = "|TInterface\\RaidFrame\\ReadyCheck-Ready:14|t"

local function SetFramePointFromDB(frame, pos)
    frame:ClearAllPoints()
    frame:SetPoint(pos.point or "CENTER", UIParent, pos.relativePoint or "CENTER", pos.x or 0, pos.y or 0)
end

local function SaveFramePoint(frame, pos)
    local point, _, relativePoint, x, y = frame:GetPoint()
    pos.point = point or "CENTER"
    pos.relativePoint = relativePoint or "CENTER"
    pos.x = x or 0
    pos.y = y or 0
end

local function AddBackdrop(frame, alpha, borderAlpha)
    if not frame or not frame.SetBackdrop then return end
    frame:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    -- Reverted from the grey-stone experiment: keep the cleaner dark backdrop,
    -- while using Blizzard templates for buttons and scrollbars.
    frame:SetBackdropColor(0.018, 0.020, 0.026, alpha or 0.55)
    frame:SetBackdropBorderColor(0.42, 0.36, 0.28, borderAlpha or 0.55)
end

local function GetPanelOpacity()
    local db = EL and EL.db
    local value = db and db.settings and db.settings.display and db.settings.display.panelOpacity
    return math.max(0.20, math.min(1.00, tonumber(value) or 0.55))
end

local function GetLauncherOpacity()
    local db = EL and EL.db
    local value = db and db.settings and db.settings.display and db.settings.display.launcherOpacity
    return math.max(0.20, math.min(1.00, tonumber(value) or 0.50))
end

local function ApplyFrameOpacity(frame, alpha)
    if frame and frame.SetBackdropColor then
        frame:SetBackdropColor(0.018, 0.020, 0.026, alpha or 0.55)
    end
end

local function AddInnerBorder(frame)
    if not frame or frame.innerBorder then return end
    frame.innerBorder = frame:CreateTexture(nil, "BORDER")
    frame.innerBorder:SetPoint("TOPLEFT", 4, -4)
    frame.innerBorder:SetPoint("BOTTOMRIGHT", -4, 4)
    frame.innerBorder:SetColorTexture(0.75, 0.66, 0.48, 0.045)
end

local function StyleScrollBar(scrollFrame)
    -- Hide the visual scrollbar entirely while preserving normal mousewheel
    -- scrolling on the ScrollFrame/content area. The gutter is also reclaimed
    -- in LayoutPanel by anchoring the scroll frame closer to the right edge.
    if not scrollFrame then return end
    local name = scrollFrame:GetName()
    local bar = scrollFrame.ScrollBar or (name and _G[name .. "ScrollBar"])
    if bar then
        bar:Hide()
        if bar.SetAlpha then bar:SetAlpha(0) end
        if bar.EnableMouse then bar:EnableMouse(false) end
    end
    if name then
        for _, suffix in ipairs({"ScrollUpButton", "ScrollDownButton", "ScrollBarTop", "ScrollBarBottom", "ScrollBarMiddle", "ThumbTexture"}) do
            local region = _G[name .. suffix]
            if region then
                if region.Hide then region:Hide() end
                if region.SetAlpha then region:SetAlpha(0) end
                if region.EnableMouse then region:EnableMouse(false) end
            end
        end
    end
end

local function ClearButtonTexture(button, getterName)
    if not button or not button[getterName] then return end
    local texture = button[getterName](button)
    if texture then
        texture:SetTexture(nil)
        texture:SetAlpha(0)
    end
end

local function DisableButtonArt(button)
    if not button then return end
    ClearButtonTexture(button, "GetNormalTexture")
    ClearButtonTexture(button, "GetPushedTexture")
    ClearButtonTexture(button, "GetHighlightTexture")
    ClearButtonTexture(button, "GetDisabledTexture")
end

local function GetCurrentPanelMinHeight(panel)
    local db = EL and EL.db
    local settings = db and db.settings and db.settings.panel or {}
    local charShown = settings.charactersShown ~= false
    local charCollapsed = settings.charactersCollapsed and true or false
    local sessionShown = db and db.settings and db.settings.session and db.settings.session.shown ~= false
    local sessionCollapsed = settings.sessionCollapsed and true or false

    -- Match the visual spacing used in LayoutPanel. The character rows can
    -- scroll, but the active section headers and the session body should never
    -- be clipped by manual resizing.
    local topPadding = 58
    local charHeaderH = charShown and 32 or 0
    local charBodyMinH = (charShown and not charCollapsed) and 76 or 0 -- about three rows plus breathing room
    local betweenSections = (charShown and sessionShown) and 8 or 0
    local sessionH = sessionShown and (sessionCollapsed and SESSION_COLLAPSED_H or SESSION_EXPANDED_H) or 0
    local actionBarShown = settings.actionBarShown ~= false
    local actionBarH = actionBarShown and ACTION_BAR_H or 0
    local bottomPadding = actionBarShown and 42 or 30

    return math.max(PANEL_MIN_H, topPadding + charHeaderH + charBodyMinH + betweenSections + sessionH + actionBarH + bottomPadding)
end

local function ClampPanelSize(panel)
    if not panel then return end
    local minH = GetCurrentPanelMinHeight(panel)
    local w = math.max(PANEL_MIN_W, math.min(PANEL_MAX_W, panel:GetWidth() or PANEL_MIN_W))
    local h = math.max(minH, math.min(PANEL_MAX_H, panel:GetHeight() or minH))
    if math.abs((panel:GetWidth() or 0) - w) > 1 or math.abs((panel:GetHeight() or 0) - h) > 1 then
        panel:SetSize(w, h)
    end
end

function EL:SaveExpandedPanelHeight()
    local p = self.panel
    local settings = self.db and self.db.settings and self.db.settings.panel
    if not p or not settings then return end

    -- Remember a useful expanded height so collapsing does not permanently
    -- trap the window at a tiny size when the character list is reopened.
    if not settings.charactersCollapsed then
        local h = math.floor(p:GetHeight() or 0)
        if h and h > PANEL_MIN_H then
            settings.expandedHeight = math.max(PANEL_MIN_H, math.min(PANEL_MAX_H, h))
        end
    end
end

function EL:ToggleCharacterSectionCollapsed()
    local settings = self.db and self.db.settings and self.db.settings.panel
    if not settings then return end

    local wasCollapsed = settings.charactersCollapsed and true or false
    if not wasCollapsed then
        self:SaveExpandedPanelHeight()
    end

    settings.charactersCollapsed = not wasCollapsed

    if self.LayoutPanel then self:LayoutPanel() end
    if self.AutoSizePanelHeight then
        self:AutoSizePanelHeight(wasCollapsed and "expandCharacter" or "collapseCharacter")
    end
    if self.RequestUpdate then self:RequestUpdate() end
end

function EL:ToggleSessionSectionCollapsed()
    local settings = self.db and self.db.settings and self.db.settings.panel
    if not settings then return end

    local wasCollapsed = settings.sessionCollapsed and true or false
    if not settings.charactersCollapsed then
        self:SaveExpandedPanelHeight()
    end

    settings.sessionCollapsed = not wasCollapsed

    if self.LayoutPanel then self:LayoutPanel() end
    if self.AutoSizePanelHeight then
        self:AutoSizePanelHeight(wasCollapsed and "expandSession" or "collapseSession")
    end
    if self.RequestUpdate then self:RequestUpdate() end
end

local HEADER_LABELS = {
    character = "Character",
    prof = "Prof.",
    conc = "Conc.",
    mulch = "Mulch",
}

local function GetColumnLayout(width, showMulch)
    width = math.max(1, tonumber(width) or 1)
    local margin = 3
    local gap = 5
    showMulch = showMulch ~= false

    -- Compact sequential layout. The character column remains flexible and
    -- truncates with ellipses, while the numeric columns stay tight enough to
    -- allow a narrower main window.
    local layout = {
        profW = 40,
        concW = 78,
        mulchW = showMulch and 74 or 0,
        showMulch = showMulch,
    }

    local gapCount = showMulch and 3 or 2
    local fixedW = (margin * 2) + (gap * gapCount) + layout.profW + layout.concW + layout.mulchW
    layout.nameX = margin
    layout.nameW = math.max(58, width - fixedW)
    layout.profX = layout.nameX + layout.nameW + gap
    layout.concX = layout.profX + layout.profW + gap
    layout.mulchX = layout.concX + layout.concW + gap
    return layout
end

local function AnchorColumnText(fs, parent, x, width, justify)
    fs:ClearAllPoints()
    fs:SetPoint("LEFT", parent, "LEFT", x, 0)
    fs:SetPoint("RIGHT", parent, "LEFT", x + width, 0)
    fs:SetWidth(width)
    fs:SetJustifyH(justify or "LEFT")
    if fs.SetWordWrap then fs:SetWordWrap(false) end
    if fs.SetNonSpaceWrap then fs:SetNonSpaceWrap(false) end
end

local function GetTextWidth(fs)
    if not fs then return 0 end
    if fs.GetUnboundedStringWidth then return fs:GetUnboundedStringWidth() or 0 end
    return fs:GetStringWidth() or 0
end

local function FormatSessionTime(seconds)
    seconds = math.max(0, tonumber(seconds) or 0)
    local hours = math.floor(seconds / 3600)
    local mins = math.floor((seconds % 3600) / 60)
    local secs = math.floor(seconds % 60)
    if hours > 0 then
        return string.format("%dh %02dm", hours, mins)
    end
    return string.format("%dm %02ds", mins, secs)
end

local function CreateHeaderButton(parent, fontString, sortKey)
    local b = CreateFrame("Button", nil, parent)
    DisableButtonArt(b)
    b.sortKey = sortKey
    b.fontString = fontString
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.bg:SetColorTexture(1, 0.72, 0.22, 0)
    b:SetScript("OnClick", function(self)
        EL:SetSortKey(self.sortKey)
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Sort by " .. (HEADER_LABELS[self.sortKey] or self.sortKey), 1, 0.82, 0.24)
        GameTooltip:AddLine("Click again to reverse the order.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return b
end


function EL:ApplyDisplaySettings()
    if self.panel then
        ApplyFrameOpacity(self.panel, GetPanelOpacity())
    end
    if self.button then
        ApplyFrameOpacity(self.button, GetLauncherOpacity())
    end
    if self.settingsPanel then
        ApplyFrameOpacity(self.settingsPanel, GetPanelOpacity())
    end
end

local function StyleBlizzardButton(button)
    if not button then return end
    if button.SetNormalFontObject then button:SetNormalFontObject(GameFontNormalSmall) end
    if button.SetHighlightFontObject then button:SetHighlightFontObject(GameFontHighlightSmall) end
    if button.SetDisabledFontObject then button:SetDisabledFontObject(GameFontDisableSmall) end
end

local function AddSoftDivider(parent, x, yTop, yBottom)
    local line = parent:CreateTexture(nil, "BORDER")
    line:SetWidth(1)
    line:SetColorTexture(0.95, 0.82, 0.42, 0.22)
    line:SetPoint("TOPLEFT", parent, "TOPLEFT", x, yTop)
    line:SetPoint("BOTTOMLEFT", parent, "TOPLEFT", x, yBottom)
    return line
end

local function CreateMetricBlock(parent, label)
    local f = CreateFrame("Frame", nil, parent)
    f.label = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    f.label:SetPoint("TOP", f, "TOP", 0, 0)
    f.label:SetText(label)
    f.label:SetTextColor(0.55, 0.78, 0.98)
    f.value = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.value:SetPoint("TOP", f.label, "BOTTOM", 0, -3)
    f.value:SetTextColor(0.92, 0.90, 0.84)
    f.value:SetJustifyH("CENTER")
    return f
end

local function MakeSettingsButton(parent, text, width, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width or 58, 22)
    b:SetText(text)
    b.text = b:GetFontString()
    if b.text then
        b.text:SetPoint("CENTER")
        b.text:SetText(text)
    end
    StyleBlizzardButton(b)
    b:SetScript("OnClick", onClick)
    return b
end

function EL:CreateSettingsPanel(parent)
    if self.settingsPanel then return self.settingsPanel end
    local f = CreateFrame("Frame", "EmberLedgerSettingsPanel", parent or UIParent, "BackdropTemplate")
    self.settingsPanel = f
    f:SetSize(320, 510)
    f:SetFrameStrata("DIALOG")
    AddBackdrop(f, GetPanelOpacity(), 0.45)
    f:SetPoint("TOPLEFT", self.panel or UIParent, "TOPRIGHT", 8, 0)
    f:Hide()

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.title:SetPoint("TOPLEFT", 14, -12)
    f.title:SetText("EmberLedger Options")
    f.title:SetTextColor(1.00, 0.82, 0.24)

    f.close = MakeSettingsButton(f, "×", 24, function() f:Hide() end)
    f.close:SetPoint("TOPRIGHT", -10, -10)

    local y = -46
    local function label(text)
        local fs = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("TOPLEFT", 16, y)
        fs:SetTextColor(0.88, 0.86, 0.78)
        fs:SetText(text)
        return fs
    end
    local function valueText()
        local fs = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("TOPRIGHT", -16, y)
        fs:SetJustifyH("RIGHT")
        fs:SetTextColor(1.00, 0.96, 0.78)
        return fs
    end
    local function sectionHeader(text)
        local fs = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        fs:SetPoint("TOPLEFT", 16, y)
        fs:SetText(text)
        fs:SetTextColor(1.00, 0.82, 0.24)
        local line = f:CreateTexture(nil, "BORDER")
        line:SetColorTexture(1.00, 0.82, 0.32, 0.22)
        line:SetHeight(1)
        line:SetPoint("LEFT", fs, "RIGHT", 8, 0)
        line:SetPoint("RIGHT", f, "RIGHT", -16, 0)
        return fs
    end

    f.panelOpacityLabel = label("Window opacity")
    f.panelOpacityValue = valueText()
    f.panelOpacityMinus = MakeSettingsButton(f, "-", 24, function() EL:AdjustSetting("panelOpacity", -0.05) end)
    f.panelOpacityMinus:SetPoint("TOPRIGHT", -80, y + 2)
    f.panelOpacityPlus = MakeSettingsButton(f, "+", 24, function() EL:AdjustSetting("panelOpacity", 0.05) end)
    f.panelOpacityPlus:SetPoint("LEFT", f.panelOpacityMinus, "RIGHT", 4, 0)

    y = y - 30
    f.launcherOpacityLabel = label("Launcher opacity")
    f.launcherOpacityValue = valueText()
    f.launcherOpacityMinus = MakeSettingsButton(f, "-", 24, function() EL:AdjustSetting("launcherOpacity", -0.05) end)
    f.launcherOpacityMinus:SetPoint("TOPRIGHT", -80, y + 2)
    f.launcherOpacityPlus = MakeSettingsButton(f, "+", 24, function() EL:AdjustSetting("launcherOpacity", 0.05) end)
    f.launcherOpacityPlus:SetPoint("LEFT", f.launcherOpacityMinus, "RIGHT", 4, 0)

    y = y - 30
    f.thresholdLabel = label("Conc threshold")
    f.thresholdValue = valueText()
    f.thresholdMinus = MakeSettingsButton(f, "-10", 36, function() EL:AdjustSetting("concThreshold", -10) end)
    f.thresholdMinus:SetPoint("TOPRIGHT", -92, y + 2)
    f.thresholdPlus = MakeSettingsButton(f, "+10", 36, function() EL:AdjustSetting("concThreshold", 10) end)
    f.thresholdPlus:SetPoint("LEFT", f.thresholdMinus, "RIGHT", 4, 0)

    y = y - 30
    f.scaleLabel = label("Window scale")
    f.scaleValue = valueText()
    f.scaleMinus = MakeSettingsButton(f, "-", 24, function() EL:AdjustSetting("panelScale", -0.05) end)
    f.scaleMinus:SetPoint("TOPRIGHT", -80, y + 2)
    f.scalePlus = MakeSettingsButton(f, "+", 24, function() EL:AdjustSetting("panelScale", 0.05) end)
    f.scalePlus:SetPoint("LEFT", f.scaleMinus, "RIGHT", 4, 0)

    y = y - 34
    f.launcherHeader = sectionHeader("Launcher lines")

    y = y - 28
    f.toggleConc = MakeSettingsButton(f, "Conc alert", 84, function() EL:ToggleDisplaySetting("showLauncherConc") end)
    f.toggleConc:SetPoint("TOPLEFT", 16, y)
    f.toggleMulch = MakeSettingsButton(f, "Mulch", 66, function() EL:ToggleDisplaySetting("showLauncherMulch") end)
    f.toggleMulch:SetPoint("LEFT", f.toggleConc, "RIGHT", 6, 0)
    f.toggleSession = MakeSettingsButton(f, "Gold/hr", 70, function() EL:ToggleDisplaySetting("showLauncherSession") end)
    f.toggleSession:SetPoint("LEFT", f.toggleMulch, "RIGHT", 6, 0)

    y = y - 28
    f.toggleTotal = MakeSettingsButton(f, "Session total", 112, function() EL:ToggleDisplaySetting("showLauncherSessionTotal") end)
    f.toggleTotal:SetPoint("TOPLEFT", 16, y)
    f.toggleTime = MakeSettingsButton(f, "Session time", 104, function() EL:ToggleDisplaySetting("showLauncherSessionTime") end)
    f.toggleTime:SetPoint("LEFT", f.toggleTotal, "RIGHT", 6, 0)

    y = y - 34
    f.windowHeader = sectionHeader("Main window sections")

    y = y - 28
    f.toggleCharactersSection = MakeSettingsButton(f, "Characters", 94, function() EL:ToggleSectionSetting("characters") end)
    f.toggleCharactersSection:SetPoint("TOPLEFT", 16, y)
    f.toggleSessionSection = MakeSettingsButton(f, "Session", 78, function() EL:ToggleSectionSetting("session") end)
    f.toggleSessionSection:SetPoint("LEFT", f.toggleCharactersSection, "RIGHT", 6, 0)
    f.toggleActionBar = MakeSettingsButton(f, "Convenience", 104, function() EL:ToggleSectionSetting("actions") end)
    f.toggleActionBar:SetPoint("LEFT", f.toggleSessionSection, "RIGHT", 6, 0)

    y = y - 34
    f.actionsHeader = sectionHeader("Actions")

    y = y - 28
    f.resetHidden = MakeSettingsButton(f, "Reset Hidden", 96, function() EL:RestoreHiddenCharacters() end)
    f.resetHidden:SetPoint("TOPLEFT", 16, y)
    f.resetPos = MakeSettingsButton(f, "Reset Position", 104, function() EL:ResetWindowPositions() end)
    f.resetPos:SetPoint("LEFT", f.resetHidden, "RIGHT", 8, 0)

    y = y - 28
    f.resetSession = MakeSettingsButton(f, "Reset Session", 106, function() EL:ResetSession() end)
    f.resetSession:SetPoint("TOPLEFT", 16, y)

    return f
end

function EL:RefreshSettingsPanel()
    local f = self.settingsPanel
    if not f then return end
    local display = self.db.settings.display
    local alerts = self.db.settings.alerts
    f.panelOpacityValue:SetText(string.format("%d%%", math.floor((tonumber(display.panelOpacity) or 0.55) * 100 + 0.5)))
    f.launcherOpacityValue:SetText(string.format("%d%%", math.floor((tonumber(display.launcherOpacity) or 0.50) * 100 + 0.5)))
    f.thresholdValue:SetText(tostring(tonumber(alerts.concentrationThreshold) or 360))
    if f.scaleValue then
        local scale = self.db.settings.panel and tonumber(self.db.settings.panel.scale) or 1
        f.scaleValue:SetText(string.format("%d%%", math.floor(scale * 100 + 0.5)))
    end
    local function setToggle(btn, on)
        if not btn or not btn.text then return end
        btn.text:SetTextColor(on and 0.62 or 0.55, on and 0.88 or 0.58, on and 0.70 or 0.62)
    end
    setToggle(f.toggleConc, display.showLauncherConc ~= false)
    setToggle(f.toggleMulch, display.showLauncherMulch ~= false)
    setToggle(f.toggleSession, display.showLauncherSession ~= false)
    setToggle(f.toggleTotal, display.showLauncherSessionTotal ~= false)
    setToggle(f.toggleTime, display.showLauncherSessionTime ~= false)
    local panelSettings = self.db.settings.panel or {}
    local sessionSettings = self.db.settings.session or {}
    setToggle(f.toggleCharactersSection, panelSettings.charactersShown ~= false)
    setToggle(f.toggleSessionSection, sessionSettings.shown ~= false)
    setToggle(f.toggleActionBar, panelSettings.actionBarShown ~= false)
end

function EL:ToggleSettingsPanel()
    if not self.settingsPanel then self:CreateSettingsPanel(self.panel or UIParent) end
    if self.settingsPanel:IsShown() then
        self.settingsPanel:Hide()
    else
        self.settingsPanel:ClearAllPoints()
        self.settingsPanel:SetPoint("TOPLEFT", self.panel or UIParent, "TOPRIGHT", 8, 0)
        self:RefreshSettingsPanel()
        self.settingsPanel:Show()
    end
end

function EL:AdjustSetting(kind, delta)
    self.db.settings.display = self.db.settings.display or {}
    self.db.settings.alerts = self.db.settings.alerts or {}
    if kind == "panelOpacity" then
        local v = tonumber(self.db.settings.display.panelOpacity) or 0.55
        self.db.settings.display.panelOpacity = math.max(0.20, math.min(1.00, v + (delta or 0)))
    elseif kind == "launcherOpacity" then
        local v = tonumber(self.db.settings.display.launcherOpacity) or 0.50
        self.db.settings.display.launcherOpacity = math.max(0.20, math.min(1.00, v + (delta or 0)))
    elseif kind == "concThreshold" then
        local v = tonumber(self.db.settings.alerts.concentrationThreshold) or 360
        self.db.settings.alerts.concentrationThreshold = math.max(0, math.min(1000, v + (delta or 0)))
    elseif kind == "panelScale" then
        self.db.settings.panel = self.db.settings.panel or {}
        local v = tonumber(self.db.settings.panel.scale) or 1
        self.db.settings.panel.scale = math.max(PANEL_MIN_SCALE, math.min(PANEL_MAX_SCALE, v + (delta or 0)))
        if self.ApplyPanelScale then self:ApplyPanelScale() end
    end
    self:ApplyDisplaySettings()
    self:RefreshSettingsPanel()
    self:RequestUpdate()
end

function EL:ToggleDisplaySetting(key)
    self.db.settings.display = self.db.settings.display or {}
    self.db.settings.display[key] = not (self.db.settings.display[key] ~= false)
    self:RefreshSettingsPanel()
    self:RequestUpdate()
end



function EL:ToggleSectionSetting(section)
    self.db.settings.panel = self.db.settings.panel or {}
    self.db.settings.session = self.db.settings.session or {}
    if section == "characters" then
        self.db.settings.panel.charactersShown = not (self.db.settings.panel.charactersShown ~= false)
    elseif section == "session" then
        self.db.settings.session.shown = not (self.db.settings.session.shown ~= false)
    elseif section == "actions" then
        self.db.settings.panel.actionBarShown = not (self.db.settings.panel.actionBarShown ~= false)
    end
    if self.LayoutPanel then self:LayoutPanel() end
    if self.AutoSizePanelHeight then self:AutoSizePanelHeight("sectionToggle") end
    self:RefreshSettingsPanel()
    self:RequestUpdate()
end

function EL:CreateUI()
    if self.uiCreated then return end
    self.uiCreated = true
    self:CreateMainButton()
    self:CreatePanel()
    if self.db and self.db.settings and self.db.settings.panel and self.db.settings.panel.windowOpen then
        C_Timer.After(0, function()
            if EL.ShowPanelFromSavedState then EL:ShowPanelFromSavedState() end
        end)
    end
    if ticker then ticker:Cancel() end
    ticker = C_Timer.NewTicker(1, function() EL:RequestUpdate() end)
end

function EL:CreateMainButton()
    local s = self.db.settings.button
    local button = CreateFrame("Button", "EmberLedgerButton", UIParent, "BackdropTemplate")
    self.button = button
    button:SetSize(math.max(162, tonumber(s.width) or 162), math.max(62, tonumber(s.height) or 62))
    button:SetClampedToScreen(true)
    button:SetMovable(true)
    button:EnableMouse(true)
    button:RegisterForDrag("LeftButton")
    AddBackdrop(button, GetLauncherOpacity(), 0.50)
    AddInnerBorder(button)
    if button.SetBackdropColor then button:SetBackdropColor(0.018, 0.020, 0.026, GetLauncherOpacity()) end
    if button.SetBackdropBorderColor then button:SetBackdropBorderColor(0.42, 0.36, 0.28, 0.62) end

    button.title = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    button.title:SetPoint("TOPLEFT", 10, -7)
    button.title:SetPoint("TOPRIGHT", -10, -7)
    button.title:SetJustifyH("CENTER")
    button.title:SetText("EmberLedger")
    if button.title.SetFontObject then button.title:SetFontObject(GameFontNormalLarge) end
    button.title:SetTextColor(1.00, 0.82, 0.24)
    button.title:SetShadowColor(0.00, 0.00, 0.00, 1.00)
    button.title:SetShadowOffset(1, -1)
    if button.title.SetWordWrap then button.title:SetWordWrap(false) end

    button.titleGlow = button:CreateTexture(nil, "BACKGROUND")
    button.titleGlow:SetPoint("TOPLEFT", button, "TOPLEFT", 12, -8)
    button.titleGlow:SetPoint("TOPRIGHT", button, "TOPRIGHT", -12, -8)
    button.titleGlow:SetHeight(18)
    button.titleGlow:SetColorTexture(0.00, 0.00, 0.00, 0.16)

    button.titleRule = button:CreateTexture(nil, "ARTWORK")
    button.titleRule:SetPoint("TOPLEFT", button.title, "BOTTOMLEFT", 10, -3)
    button.titleRule:SetPoint("TOPRIGHT", button.title, "BOTTOMRIGHT", -10, -3)
    button.titleRule:SetHeight(1)
    button.titleRule:SetColorTexture(1.00, 0.82, 0.32, 0.38)

    button.line1 = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.line1:SetPoint("TOPLEFT", button.title, "BOTTOMLEFT", 0, -7)
    button.line1:SetPoint("TOPRIGHT", button.title, "BOTTOMRIGHT", 0, -7)
    button.line1:SetJustifyH("CENTER")
    if button.line1.SetWordWrap then button.line1:SetWordWrap(false) end

    button.line2 = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.line2:SetPoint("TOPLEFT", button.line1, "BOTTOMLEFT", 0, -3)
    button.line2:SetPoint("TOPRIGHT", button.line1, "BOTTOMRIGHT", 0, -3)
    button.line2:SetJustifyH("CENTER")
    if button.line2.SetWordWrap then button.line2:SetWordWrap(false) end
    button.line2:SetTextColor(0.90, 0.88, 0.78)

    button.line3 = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.line3:SetPoint("TOPLEFT", button.line2, "BOTTOMLEFT", 0, -3)
    button.line3:SetPoint("TOPRIGHT", button.line2, "BOTTOMRIGHT", 0, -3)
    button.line3:SetJustifyH("CENTER")
    if button.line3.SetWordWrap then button.line3:SetWordWrap(false) end
    button.line3:SetTextColor(0.82, 0.82, 0.76)

    button.line4 = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.line4:SetPoint("TOPLEFT", button.line3, "BOTTOMLEFT", 0, -3)
    button.line4:SetPoint("TOPRIGHT", button.line3, "BOTTOMRIGHT", 0, -3)
    button.line4:SetJustifyH("CENTER")
    if button.line4.SetWordWrap then button.line4:SetWordWrap(false) end
    button.line4:SetTextColor(0.74, 0.76, 0.72)

    button.line5 = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    button.line5:SetPoint("TOPLEFT", button.line4, "BOTTOMLEFT", 0, -3)
    button.line5:SetPoint("TOPRIGHT", button.line4, "BOTTOMRIGHT", 0, -3)
    button.line5:SetJustifyH("CENTER")
    if button.line5.SetWordWrap then button.line5:SetWordWrap(false) end
    button.line5:SetTextColor(0.78, 0.78, 0.72)

    button.hover = button:CreateTexture(nil, "HIGHLIGHT")
    button.hover:SetAllPoints()
    button.hover:SetColorTexture(1.00, 0.82, 0.32, 0.10)

    button:SetScript("OnDragStart", function(self)
        local settings = EL.db.settings.button
        if not settings.locked or IsShiftKeyDown() then
            self:StartMoving()
        end
    end)
    button:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SaveFramePoint(self, EL.db.settings.button)
    end)
    button:SetScript("OnClick", function(_, mouseButton)
        if mouseButton == "RightButton" then
            EL:ToggleLauncherLock()
        else
            EL:TogglePanel()
        end
    end)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:SetScript("OnEnter", function(self) EL:ShowButtonTooltip(self) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)

    SetFramePointFromDB(button, s)
end


local function GetItemIconByIDOrName(itemID, itemName, fallback)
    if itemID and GetItemInfoInstant then
        local _, _, _, _, icon = GetItemInfoInstant(itemID)
        if icon then return icon end
    end
    if itemName and GetItemInfoInstant then
        local _, _, _, _, icon = GetItemInfoInstant(itemName)
        if icon then return icon end
    end
    return fallback or "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function GetSpellIconSafe(spellID, spellName, fallback)
    if C_Spell and C_Spell.GetSpellInfo then
        local ok, info = pcall(C_Spell.GetSpellInfo, spellID or spellName)
        if ok and info and info.iconID then return info.iconID end
    end
    if GetSpellInfo then
        local ok, _, _, icon = pcall(GetSpellInfo, spellID or spellName)
        if ok and icon then return icon end
    end
    return fallback or "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function GetToyIconSafe(itemID, itemName, fallback)
    if itemID and C_ToyBox and C_ToyBox.GetToyInfo then
        local ok, _, name, icon = pcall(C_ToyBox.GetToyInfo, itemID)
        if ok and icon then return icon end
    end
    return GetItemIconByIDOrName(itemID, itemName, fallback)
end

local function GetActionIcon(info)
    if info.kind == "spell" then
        return GetSpellIconSafe(info.spellID, info.name, info.fallback)
    elseif info.kind == "toy" then
        return GetToyIconSafe(info.itemID, info.name, info.fallback)
    else
        return GetItemIconByIDOrName(info.itemID, info.name, info.fallback)
    end
end

local function GetItemCountSafe(itemID, itemName)
    local item = itemID or itemName
    if not item then return 0 end
    if C_Item and C_Item.GetItemCount then
        local ok, count = pcall(C_Item.GetItemCount, item, false, false, false, true)
        if ok and tonumber(count) then return tonumber(count) end
        ok, count = pcall(C_Item.GetItemCount, item)
        if ok and tonumber(count) then return tonumber(count) end
    end
    if GetItemCount then
        local ok, count = pcall(GetItemCount, item, false, false, true)
        if ok and tonumber(count) then return tonumber(count) end
        ok, count = pcall(GetItemCount, item)
        if ok and tonumber(count) then return tonumber(count) end
    end
    return 0
end

local function PlayerHasToySafe(itemID)
    if not itemID then return false end
    if C_ToyBox and C_ToyBox.PlayerHasToy then
        local ok, hasToy = pcall(C_ToyBox.PlayerHasToy, itemID)
        if ok then return hasToy and true or false end
    end
    if PlayerHasToy then
        local ok, hasToy = pcall(PlayerHasToy, itemID)
        if ok then return hasToy and true or false end
    end
    return false
end

local function PlayerKnowsSpellSafe(spellID, spellName)
    if spellID then
        if IsPlayerSpell then
            local ok, known = pcall(IsPlayerSpell, spellID)
            if ok and known then return true end
        end
        if C_SpellBook and C_SpellBook.IsSpellKnown then
            local ok, known = pcall(C_SpellBook.IsSpellKnown, spellID)
            if ok and known then return true end
        end
    end
    if spellName and GetSpellInfo then
        local ok, name = pcall(GetSpellInfo, spellName)
        if ok and name then return true end
    end
    return false
end

local function ResolveKnownSpellID(info)
    if not info then return nil end
    if info.spellID and PlayerKnowsSpellSafe(info.spellID, info.name) then return info.spellID end
    if info.spellIDs then
        for _, spellID in ipairs(info.spellIDs) do
            if PlayerKnowsSpellSafe(spellID, info.name) then return spellID end
        end
    end
    if info.name and PlayerKnowsSpellSafe(nil, info.name) then return info.name end
    return info.spellID or info.name
end

local function GetActionAvailable(info)
    if info.kind == "toy" then
        return PlayerHasToySafe(info.itemID)
    elseif info.kind == "spell" then
        return ResolveKnownSpellID(info) ~= nil
    else
        return GetItemCountSafe(info.itemID, info.name) > 0
    end
end

local function GetActionCooldownSafe(info)
    if not info then return 0, 0, 0 end
    if info.kind == "spell" then
        local spell = ResolveKnownSpellID(info)
        if C_Spell and C_Spell.GetSpellCooldown then
            local ok, cd = pcall(C_Spell.GetSpellCooldown, spell)
            if ok and cd then
                return cd.startTime or 0, cd.duration or 0, cd.isEnabled and 1 or 0
            end
        end
        if GetSpellCooldown then
            local ok, start, duration, enable = pcall(GetSpellCooldown, spell)
            if ok and start then return start or 0, duration or 0, enable or 0 end
        end
        return 0, 0, 0
    elseif info.kind == "toy" then
        if info.itemID and C_ToyBox and C_ToyBox.GetToyCooldown then
            local ok, start, duration, enable = pcall(C_ToyBox.GetToyCooldown, info.itemID)
            if ok and start then return start or 0, duration or 0, enable or 0 end
        end
        if info.itemID and C_Item and C_Item.GetItemCooldown then
            local ok, start, duration, enable = pcall(C_Item.GetItemCooldown, info.itemID)
            if ok and start then return start or 0, duration or 0, enable or 0 end
        end
        if info.itemID and GetItemCooldown then
            local ok, start, duration, enable = pcall(GetItemCooldown, info.itemID)
            if ok and start then return start or 0, duration or 0, enable or 0 end
        end
        return 0, 0, 0
    else
        local item = info.itemID or info.name
        if not item then return 0, 0, 0 end
        if C_Container and C_Container.GetItemCooldown then
            local ok, start, duration, enable = pcall(C_Container.GetItemCooldown, item)
            if ok and start then return start or 0, duration or 0, enable or 0 end
        end
        if C_Item and C_Item.GetItemCooldown then
            local ok, start, duration, enable = pcall(C_Item.GetItemCooldown, item)
            if ok and start then return start or 0, duration or 0, enable or 0 end
        end
        if GetItemCooldown then
            local ok, start, duration, enable = pcall(GetItemCooldown, item)
            if ok and start then return start or 0, duration or 0, enable or 0 end
        end
        return 0, 0, 0
    end
end

local function MakeIconActionButton(parent, info)
    -- Secure action buttons must not call UseItemByName or Logout directly.
    -- This mirrors the working MulchTracker pattern, with explicit left-click
    -- attributes added for compatibility with action button handling.
    local name = "EmberLedgerActionButton_" .. tostring(info.key or math.random(100000))
    local b = CreateFrame("Button", name, parent, "SecureActionButtonTemplate")
    b:SetSize(28, 28)
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:EnableMouse(true)

    if info.kind == "item" then
        local itemRef = info.itemID and ("item:" .. tostring(info.itemID)) or tostring(info.name or info.label or "")
        b:SetAttribute("type", "item")
        b:SetAttribute("type1", "item")
        b:SetAttribute("item", itemRef)
        b:SetAttribute("item1", itemRef)
    elseif info.kind == "toy" then
        local macrotext = info.name and ("/use " .. tostring(info.name)) or (info.itemID and ("/use item:" .. tostring(info.itemID)) or "")
        b:SetAttribute("type", "macro")
        b:SetAttribute("type1", "macro")
        b:SetAttribute("macrotext", macrotext)
        b:SetAttribute("macrotext1", macrotext)
    elseif info.kind == "spell" then
        local macrotext = "/cast " .. tostring(info.name or info.label or "")
        b:SetAttribute("type", "macro")
        b:SetAttribute("type1", "macro")
        b:SetAttribute("macrotext", macrotext)
        b:SetAttribute("macrotext1", macrotext)
    else
        local macrotext = "/use " .. tostring(info.name or info.label or "")
        b:SetAttribute("type", "macro")
        b:SetAttribute("type1", "macro")
        b:SetAttribute("macrotext", macrotext)
        b:SetAttribute("macrotext1", macrotext)
    end

    b.actionInfo = info
    b.actionKey = info.key
    b.actionLabel = info.label or info.name
    b.hideWhenMissing = info.hideWhenMissing and true or false

    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.bg:SetColorTexture(0, 0, 0, 0.42)

    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetPoint("TOPLEFT", 3, -3)
    b.icon:SetPoint("BOTTOMRIGHT", -3, 3)
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b.icon:SetTexture(GetActionIcon(info))

    b.border = CreateFrame("Frame", nil, b, "BackdropTemplate")
    b.border:SetPoint("TOPLEFT", b, "TOPLEFT", 0, 0)
    b.border:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", 0, 0)
    b.border:EnableMouse(false)
    b.border:SetBackdrop({
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 12,
        insets = { left = 2, right = 2, top = 2, bottom = 2 },
    })
    b.border:SetBackdropBorderColor(0.62, 0.50, 0.25, 0.78)

    b.cooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cooldown:SetAllPoints(b.icon)
    b.cooldown:EnableMouse(false)

    b.highlight = b:CreateTexture(nil, "HIGHLIGHT")
    b.highlight:SetAllPoints(b.icon)
    b.highlight:SetColorTexture(1, 0.82, 0.35, 0.16)

    b:SetScript("OnEnter", function(self)
        local inf = self.actionInfo or {}
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        if inf.kind == "spell" then
            if inf.spellID and GameTooltip.SetSpellByID then
                GameTooltip:SetSpellByID(inf.spellID)
            else
                GameTooltip:SetText(self.actionLabel or "Spell", 1, 0.82, 0.24)
            end
        elseif inf.kind == "toy" then
            if inf.itemID then GameTooltip:SetItemByID(inf.itemID) else GameTooltip:SetText(self.actionLabel or "Toy", 1, 0.82, 0.24) end
        else
            if inf.itemID then GameTooltip:SetHyperlink("item:" .. tostring(inf.itemID)) else GameTooltip:SetText(self.actionLabel or "Item", 1, 0.82, 0.24) end
            local count = GetItemCountSafe(inf.itemID, inf.name)
            GameTooltip:AddLine(" ")
            GameTooltip:AddDoubleLine("Available", tostring(count or 0), 0.72, 0.72, 0.72, 1, 1, 1)
        end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return b
end

local function MakeLogoutButton(parent)
    -- Visible Blizzard button with a secure child owning the actual hardware click.
    -- This matches the MulchTracker pattern and avoids protected Logout() calls.
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(72, 28)
    button:SetText("Logout")
    StyleBlizzardButton(button)

    local secure = CreateFrame("Button", "EmberLedgerSecureLogoutButton", button, "SecureActionButtonTemplate")
    secure:SetAllPoints(button)
    secure:SetFrameLevel((button:GetFrameLevel() or 1) + 10)
    secure:EnableMouse(true)
    secure:RegisterForClicks("AnyUp", "AnyDown")
    secure:SetAttribute("type", "macro")
    secure:SetAttribute("type1", "macro")
    secure:SetAttribute("macrotext", "/logout")
    secure:SetAttribute("macrotext1", "/logout")

    secure:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Logout", 1, 0.82, 0.24)
        GameTooltip:AddLine("Secure logout button.", 0.72, 0.72, 0.72)
        GameTooltip:Show()
    end)
    secure:SetScript("OnLeave", function() GameTooltip:Hide() end)

    button.secure = secure
    return button
end

local ACTION_ITEM_BUTTONS = {
    { key = "mulch", kind = "item", label = "Imbued Mulch", name = "Imbued Mulch", itemID = EL.IMBUED_MULCH_ITEM_ID, fallback = "Interface\\Icons\\INV_Misc_Herb_01", hideWhenMissing = false },
    { key = "seed", kind = "item", label = "Resilient Seed", name = "Resilient Seed", itemID = 237497, fallback = "Interface\\Icons\\INV_Misc_Herb_06", hideWhenMissing = true },
    { key = "parcel", kind = "toy", label = "Interdimensional Parcel Signal", name = "Interdimensional Parcel Signal", itemID = 264695, fallback = "Interface\\Icons\\INV_Misc_EngGizmos_27", hideWhenMissing = true },
    { key = "bank", kind = "spell", label = "Warband Bank Distance Inhibitor", name = "Warband Bank Distance Inhibitor", spellID = 460905, spellIDs = { 460905, 465226, 460925 }, fallback = "Interface\\Icons\\INV_Engineering_90_WormholeGenerator_PortalBlue", hideWhenMissing = true },
}

function EL:CreateActionBar(parent)
    local bar = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    parent.actionBar = bar
    bar:SetHeight(ACTION_BAR_H)
    AddBackdrop(bar, 0.18, 0.18)
    if bar.SetBackdropColor then bar:SetBackdropColor(0.018, 0.020, 0.026, 0.30) end

    bar.itemButtons = {}
    local last
    for _, info in ipairs(ACTION_ITEM_BUTTONS) do
        local b = MakeIconActionButton(bar, info)
        bar.itemButtons[info.key] = b
        if last then
            b:SetPoint("LEFT", last, "RIGHT", 4, 0)
        else
            b:SetPoint("LEFT", bar, "LEFT", 6, 0)
        end
        last = b
    end

    bar.logout = MakeLogoutButton(bar)
    bar.logout:SetPoint("RIGHT", bar, "RIGHT", -20, 0)

    self:UpdateActionBar()
end

function EL:UpdateActionBar()
    local bar = self.panel and self.panel.actionBar
    if not bar or not bar.itemButtons then return end
    local locked = InCombatLockdown and InCombatLockdown()

    local lastVisible
    for _, info in ipairs(ACTION_ITEM_BUTTONS) do
        local b = bar.itemButtons[info.key]
        if b then
            local available = GetActionAvailable(info)
            local show = (not b.hideWhenMissing) or available
            if not locked then
                b:SetShown(show)
            end
            if show or (locked and b:IsShown()) then
                if not locked then
                    b:ClearAllPoints()
                    if lastVisible then
                        b:SetPoint("LEFT", lastVisible, "RIGHT", 4, 0)
                    else
                        b:SetPoint("LEFT", bar, "LEFT", 6, 0)
                    end
                    lastVisible = b
                end

                if b.icon then
                    b.icon:SetDesaturated(not available)
                    b.icon:SetAlpha(available and 1 or 0.38)
                end
                -- Do not Enable/Disable secure action buttons during refresh.
                -- Availability is represented visually, while the secure macro action
                -- remains untouched unless attributes need an out-of-combat update.

                local start, duration, enable = GetActionCooldownSafe(info)
                if b.cooldown and CooldownFrame_Set then
                    if start and duration and duration > 1 then
                        CooldownFrame_Set(b.cooldown, start, duration, enable)
                    else
                        CooldownFrame_Set(b.cooldown, 0, 0, 0)
                    end
                elseif b.cooldown and b.cooldown.SetCooldown then
                    b.cooldown:SetCooldown(start or 0, duration or 0)
                end
            end
        end
    end
end

function EL:CreateSessionPanel(parent)
    local session = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    parent.sessionPanel = session
    session:SetHeight(SESSION_EXPANDED_H)
    AddBackdrop(session, 0.30, 0.28)
    if session.SetBackdropColor then session:SetBackdropColor(0.018, 0.020, 0.026, 0.46) end
    if session.SetBackdropBorderColor then session:SetBackdropBorderColor(0.55, 0.48, 0.36, 0.38) end

    session.header = CreateFrame("Frame", nil, session, "BackdropTemplate")
    session.header:SetHeight(28)
    session.header:SetPoint("TOPLEFT", 4, -4)
    session.header:SetPoint("TOPRIGHT", -4, -4)
    AddBackdrop(session.header, 0.24, 0.18)
    if session.header.SetBackdropColor then session.header:SetBackdropColor(0.020, 0.022, 0.028, 0.58) end

    session.collapse = CreateFrame("Button", nil, session.header, "UIPanelButtonTemplate")
    session.collapse:SetSize(22, 20)
    session.collapse:SetPoint("LEFT", session.header, "LEFT", 6, 0)
    StyleBlizzardButton(session.collapse)
    session.collapse:SetScript("OnClick", function() EL:ToggleSessionSectionCollapsed() end)
    session.collapse:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Collapse or expand session section", 1, 0.74, 0.32)
        GameTooltip:Show()
    end)
    session.collapse:SetScript("OnLeave", function() GameTooltip:Hide() end)

    session.title = session.header:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    session.title:SetPoint("LEFT", session.collapse, "RIGHT", 8, 0)
    session.title:SetPoint("RIGHT", session.header, "RIGHT", -154, 0)
    session.title:SetJustifyH("LEFT")
    session.title:SetText("Session")
    session.title:SetTextColor(1.00, 0.82, 0.24)

    session.toggle = CreateFrame("Button", nil, session.header, "UIPanelButtonTemplate")
    session.toggle:SetSize(64, 20)
    session.toggle:SetPoint("RIGHT", session.header, "RIGHT", -76, 1)
    StyleBlizzardButton(session.toggle)
    session.toggle.text = session.toggle:GetFontString()
    session.toggle:SetScript("OnClick", function() EL:ToggleSessionPause() end)

    session.reset = CreateFrame("Button", nil, session.header, "UIPanelButtonTemplate")
    session.reset:SetSize(64, 20)
    session.reset:SetPoint("LEFT", session.toggle, "RIGHT", 8, 0)
    session.reset:SetText("Reset")
    StyleBlizzardButton(session.reset)
    session.reset.text = session.reset:GetFontString()
    session.reset:SetScript("OnClick", function() EL:ResetSession() end)

    session.metrics = CreateFrame("Frame", nil, session)
    session.metrics:SetPoint("TOPLEFT", session.header, "BOTTOMLEFT", 4, -8)
    session.metrics:SetPoint("TOPRIGHT", session.header, "BOTTOMRIGHT", -4, -8)
    session.metrics:SetHeight(42)

    session.metricTime = CreateMetricBlock(session.metrics, "Session time")
    session.metricTime:SetPoint("TOPLEFT", session.metrics, "TOPLEFT", 0, 0)
    session.metricTime:SetSize(88, 38)

    session.metricValue = CreateMetricBlock(session.metrics, "Total")
    session.metricValue:SetPoint("LEFT", session.metricTime, "RIGHT", 8, 0)
    session.metricValue:SetSize(70, 38)

    session.metricRate = CreateMetricBlock(session.metrics, "Rate")
    session.metricRate:SetPoint("LEFT", session.metricValue, "RIGHT", 8, 0)
    session.metricRate:SetSize(84, 38)

    session.metricDiv1 = AddSoftDivider(session.metrics, 96, 0, -36)
    session.metricDiv2 = AddSoftDivider(session.metrics, 174, 0, -36)

    session.summary = session:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    session.summary:SetText("")
    session.summary:Hide()

    session.itemClip = CreateFrame("Frame", nil, session)
    session.itemClip:SetPoint("TOPLEFT", session.metrics, "BOTTOMLEFT", 0, -8)
    session.itemClip:SetPoint("TOPRIGHT", session.metrics, "BOTTOMRIGHT", 0, -8)
    session.itemClip:SetPoint("BOTTOMRIGHT", session, "BOTTOMRIGHT", -12, 12)
    session.itemClip:SetHeight(SESSION_VISIBLE_ITEM_ROWS * SESSION_ITEM_ROW_H)
    session.itemClip:EnableMouse(true)
    session.itemClip:EnableMouseWheel(true)
    session.itemClip:SetScript("OnMouseWheel", function(_, delta)
        local maxOffset = math.max(0, (session.itemCount or 0) - SESSION_VISIBLE_ITEM_ROWS)
        session.itemScrollOffset = math.max(0, math.min(maxOffset, (session.itemScrollOffset or 0) - (delta or 0)))
        if EL.RefreshSessionPanel then EL:RefreshSessionPanel() end
    end)
    if session.itemClip.SetClipsChildren then session.itemClip:SetClipsChildren(true) end

    session.items = {}
    for i = 1, SESSION_VISIBLE_ITEM_ROWS do
        local row = CreateFrame("Frame", nil, session.itemClip)
        row:SetSize(1, SESSION_ITEM_ROW_H)
        row:SetPoint("TOPLEFT", session.itemClip, "TOPLEFT", 0, -((i - 1) * SESSION_ITEM_ROW_H))
        row:SetPoint("RIGHT", session.itemClip, "RIGHT", 0, 0)

        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(12, 12)
        row.icon:SetPoint("LEFT", row, "LEFT", 0, 0)
        row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        row.icon:Hide()

        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.text:SetJustifyH("LEFT")
        row.text:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
        row.text:SetPoint("RIGHT", row, "RIGHT", 0, 0)
        if row.text.SetWordWrap then row.text:SetWordWrap(false) end

        session.items[i] = row
    end
end

function EL:RefreshSessionPanel()
    local p = self.panel
    local sp = p and p.sessionPanel
    if not sp then return end
    local shown = self.db and self.db.settings and self.db.settings.session and self.db.settings.session.shown ~= false
    sp:SetShown(shown)
    if not shown then return end
    local collapsed = self.db and self.db.settings and self.db.settings.panel and self.db.settings.panel.sessionCollapsed
    if sp.collapse then sp.collapse:SetText(collapsed and ">" or "v") end
    if sp.metrics then sp.metrics:SetShown(not collapsed) end
    if sp.metricDiv1 then sp.metricDiv1:SetShown(not collapsed) end
    if sp.metricDiv2 then sp.metricDiv2:SetShown(not collapsed) end
    if sp.toggle then sp.toggle:SetShown(not collapsed) end
    if sp.reset then sp.reset:SetShown(not collapsed) end
    for _, row in ipairs(sp.items or {}) do row:SetShown(not collapsed) end

    local s = self:GetSessionDB()
    local elapsed = self:GetSessionElapsedSeconds()
    local value = self:FormatMoneyText(s.totalSilver or 0)
    local gph = self:FormatMoneyText(self:GetSessionGoldPerHour()) .. "/hr"
    if sp.summary then sp.summary:SetText(""); sp.summary:Hide() end
    if sp.metricTime and sp.metricTime.value then sp.metricTime.value:SetText(FormatSessionTime(elapsed)) end
    if sp.metricValue and sp.metricValue.value then sp.metricValue.value:SetText(value) end
    if sp.metricRate and sp.metricRate.value then sp.metricRate.value:SetText(gph) end
    if sp.itemClip then sp.itemClip:SetShown(not collapsed) end
    sp.toggle:SetText(s.isPaused and "Start" or "Pause")
    if sp.toggle.text then
        sp.toggle.text:SetTextColor(s.isPaused and 0.35 or 1, s.isPaused and 1 or 0.72, s.isPaused and 0.35 or 0.2)
    end

    local warning = self:GetPricingWarning()
    local top = self:GetTopSessionItems(math.max(50, tonumber(self.db.settings.session.topItems) or 0))
    sp.itemCount = #top
    local maxOffset = math.max(0, #top - SESSION_VISIBLE_ITEM_ROWS)
    sp.itemScrollOffset = math.max(0, math.min(maxOffset, tonumber(sp.itemScrollOffset) or 0))
    local displayTop = {}
    for i = 1, SESSION_VISIBLE_ITEM_ROWS do
        displayTop[i] = top[(sp.itemScrollOffset or 0) + i]
    end
    local function ClearSessionRow(row)
        if not row then return end
        if row.icon then row.icon:Hide(); row.icon:SetTexture(nil) end
        if row.text then row.text:SetText("") end
    end

    local function SetSessionRow(row, text, r, g, b, icon)
        if not row then return end
        if icon and row.icon then
            row.icon:SetTexture(icon)
            row.icon:Show()
            row.text:ClearAllPoints()
            row.text:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
            row.text:SetPoint("RIGHT", row, "RIGHT", 0, 0)
        else
            if row.icon then row.icon:Hide(); row.icon:SetTexture(nil) end
            row.text:ClearAllPoints()
            row.text:SetPoint("LEFT", row, "LEFT", 0, 0)
            row.text:SetPoint("RIGHT", row, "RIGHT", 0, 0)
        end
        row.text:SetText(text or "")
        row.text:SetTextColor(r or 0.88, g or 0.90, b or 0.92)
    end

    if warning and (tonumber(s.totalItems) or 0) == 0 then
        SetSessionRow(sp.items[1], "Pricing: " .. warning, 0.95, 0.62, 0.26)
        for i = 2, #sp.items do ClearSessionRow(sp.items[i]) end
        return
    end
    if #top == 0 then
        SetSessionRow(sp.items[1], s.isPaused and "Session paused. Press Start before gathering." or "Gather profession materials to begin tracking value.", 0.68, 0.70, 0.72)
        for i = 2, #sp.items do ClearSessionRow(sp.items[i]) end
        return
    end
    for i, row in ipairs(sp.items) do
        local item = displayTop[i]
        if item then
            local money = self:FormatMoneyText(item.silver or 0)
            local text = string.format("%s x%d  •  %s", item.name or ("item:" .. tostring(item.itemID)), tonumber(item.qty) or 0, money)
            SetSessionRow(row, text, 0.88, 0.90, 0.92, item.icon)
        else
            ClearSessionRow(row)
        end
    end
end

function EL:CreatePanel()
    local s = self.db.settings.panel
    local panel = CreateFrame("Frame", "EmberLedgerPanel", UIParent, "BackdropTemplate")
    self.panel = panel
    panel:SetSize(math.max(PANEL_MIN_W, tonumber(s.width) or 456), math.max(PANEL_MIN_H, tonumber(s.height) or 360))
    panel:SetResizeBounds(PANEL_MIN_W, GetCurrentPanelMinHeight(panel), PANEL_MAX_W, PANEL_MAX_H)
    panel:SetMovable(true)
    panel:SetResizable(true)
    panel:EnableMouse(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetClampedToScreen(true)
    AddBackdrop(panel, 0.64, 0.62)
    if panel.SetBackdropColor then panel:SetBackdropColor(0.018, 0.020, 0.026, GetPanelOpacity()) end
    if panel.SetBackdropBorderColor then panel:SetBackdropBorderColor(0.42, 0.36, 0.28, 0.62) end
    AddInnerBorder(panel)
    panel:Hide()
    panel:SetScript("OnShow", function()
        if EL.db and EL.db.settings and EL.db.settings.panel then
            EL.db.settings.panel.windowOpen = true
        end
    end)
    panel:SetScript("OnHide", function()
        if EL.db and EL.db.settings and EL.db.settings.panel then
            EL.db.settings.panel.windowOpen = false
        end
    end)
    panel:SetScale(math.max(PANEL_MIN_SCALE, math.min(PANEL_MAX_SCALE, tonumber(s.scale) or 1)))

    panel:SetScript("OnDragStart", function(self) self:StartMoving() end)
    panel:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        EL.db.settings.panel.detached = true
        SaveFramePoint(self, EL.db.settings.panel)
    end)
    panel:SetScript("OnSizeChanged", function(self)
        if self._clampingSize or self._autoSizingHeight then return end
        local w, h = self:GetWidth(), self:GetHeight()
        local cw = math.max(PANEL_MIN_W, math.min(PANEL_MAX_W, w or PANEL_MIN_W))
        local minH = GetCurrentPanelMinHeight(self)
        local ch = math.max(minH, math.min(PANEL_MAX_H, h or minH))
        if math.abs((w or 0) - cw) > 1 or math.abs((h or 0) - ch) > 1 then
            self._clampingSize = true
            self:SetSize(cw, ch)
            self._clampingSize = false
            return
        end
        EL.db.settings.panel.width = cw
        EL.db.settings.panel.height = ch
        if not EL.db.settings.panel.charactersCollapsed and not self._autoSizingHeight then
            EL.db.settings.panel.expandedHeight = ch
        end
        if EL.LayoutPanel then EL:LayoutPanel() end
    end)

    panel.title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    panel.title:SetPoint("TOPLEFT", 14, -12)
    panel.title:SetText("EmberLedger")
    panel.title:SetTextColor(1.00, 0.82, 0.24)

    panel.summary = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.summary:SetPoint("TOPLEFT", panel.title, "BOTTOMLEFT", 0, -4)
    panel.summary:SetJustifyH("LEFT")
    panel.summary:SetTextColor(0.88, 0.86, 0.78)
    panel.summary:SetText("")
    panel.summary:Hide()

    panel.close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    panel.close:SetSize(26, 26)
    panel.close:SetPoint("TOPRIGHT", -8, -8)
    panel.close:SetScript("OnClick", function() panel:Hide() end)

    panel.settings = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    panel.settings:SetSize(64, 22)
    panel.settings:SetText("Options")
    StyleBlizzardButton(panel.settings)
    panel.settings:SetPoint("RIGHT", panel.close, "LEFT", -6, 0)
    panel.settings:SetScript("OnClick", function() EL:ToggleSettingsPanel() end)
    panel.settings:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("EmberLedger options", 1, 0.74, 0.32)
        GameTooltip:Show()
    end)
    panel.settings:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Scale controls moved to the Options panel in v0.4.24.
    panel.scaleDown = nil
    panel.scaleUp = nil

    panel.restore = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    panel.restore:SetSize(78, 22)
    panel.restore:SetText("Restore")
    StyleBlizzardButton(panel.restore)
    panel.restore:SetPoint("RIGHT", panel.settings, "LEFT", -6, 0)
    panel.restore:SetScript("OnClick", function() EL:RestoreHiddenCharacters() end)
    panel.restore:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("Restore hidden characters", 1, 0.55, 0.15)
        GameTooltip:AddLine("Right-click a row to hide a character.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    panel.restore:SetScript("OnLeave", function() GameTooltip:Hide() end)

    panel.characterToggle = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    panel.characterToggle:SetSize(22, 20)
    StyleBlizzardButton(panel.characterToggle)
    panel.characterToggle.text = panel.characterToggle:GetFontString()
    panel.characterToggle:SetScript("OnClick", function() EL:ToggleCharacterSectionCollapsed() end)
    panel.characterToggle:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Collapse or expand character cooldowns", 1, 0.74, 0.32)
        GameTooltip:Show()
    end)
    panel.characterToggle:SetScript("OnLeave", function() GameTooltip:Hide() end)

    panel.header = CreateFrame("Frame", nil, panel, "BackdropTemplate")
    panel.header:SetHeight(32)
    if panel.header.SetClipsChildren then panel.header:SetClipsChildren(true) end
    AddBackdrop(panel.header, 0.38, 0.20)
    if panel.header.SetBackdropColor then panel.header:SetBackdropColor(0.018, 0.022, 0.030, 0.54) end
    panel.header.topLine = panel.header:CreateTexture(nil, "BORDER")
    panel.header.topLine:SetHeight(1)
    panel.header.topLine:SetPoint("TOPLEFT", 2, -1)
    panel.header.topLine:SetPoint("TOPRIGHT", -2, -1)
    panel.header.topLine:SetColorTexture(0.82, 0.74, 0.58, 0.10)
    panel.header.bottomLine = panel.header:CreateTexture(nil, "BORDER")
    panel.header.bottomLine:SetHeight(1)
    panel.header.bottomLine:SetPoint("BOTTOMLEFT", 2, 1)
    panel.header.bottomLine:SetPoint("BOTTOMRIGHT", -2, 1)
    panel.header.bottomLine:SetColorTexture(0.82, 0.74, 0.58, 0.22)
    panel.header.separators = {}
    panel.header.name = panel.header:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    panel.header.prof = panel.header:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    panel.header.conc = panel.header:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    panel.header.mulch = panel.header:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    panel.header.name:SetText("Character")
    panel.header.prof:SetText("Prof.")
    panel.header.conc:SetText("Conc.")
    panel.header.mulch:SetText("Mulch")
    for _, fs in pairs({panel.header.name, panel.header.prof, panel.header.conc, panel.header.mulch}) do
        fs:SetTextColor(0.78, 0.84, 0.92)
    end
    panel.header.nameButton = CreateHeaderButton(panel.header, panel.header.name, "character")
    panel.header.profButton = CreateHeaderButton(panel.header, panel.header.prof, "prof")
    panel.header.concButton = CreateHeaderButton(panel.header, panel.header.conc, "conc")
    panel.header.mulchButton = CreateHeaderButton(panel.header, panel.header.mulch, "mulch")

    panel.scroll = CreateFrame("ScrollFrame", "EmberLedgerScrollFrame", panel, "UIPanelScrollFrameTemplate")
    StyleScrollBar(panel.scroll)
    panel.content = CreateFrame("Frame", nil, panel.scroll)
    panel.scroll:SetScrollChild(panel.content)
    panel.rows = {}

    panel.empty = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    panel.empty:SetText("No tracked professions found.")
    panel.empty:SetTextColor(0.68, 0.70, 0.72)
    panel.empty:Hide()

    self:CreateSessionPanel(panel)
    self:CreateActionBar(panel)

    panel.version = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    panel.version:SetPoint("BOTTOMLEFT", 14, 12)
    panel.version:SetText("")
    panel.version:Hide()

    panel.resize = CreateFrame("Button", nil, panel)
    panel.resize:SetSize(16, 16)
    panel.resize:SetPoint("BOTTOMRIGHT", -4, 4)
    panel.resize:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" then return end
        panel._userSizing = true
        panel._resizeStartW = panel:GetWidth() or PANEL_MIN_W
        panel._resizeStartH = panel:GetHeight() or PANEL_MIN_H
        panel._resizeStartX, panel._resizeStartY = GetCursorPosition()

        -- Force a stable TOPLEFT anchor before manual resizing. This prevents
        -- the frame from jumping when the resize grip is clicked.
        local left, top = panel:GetLeft(), panel:GetTop()
        if left and top then
            panel:ClearAllPoints()
            panel:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
        end

        self:SetScript("OnUpdate", function()
            if not panel._userSizing then return end
            local x, y = GetCursorPosition()
            local scale = panel:GetEffectiveScale() or 1
            local dx = (x - (panel._resizeStartX or x)) / scale
            local dy = (y - (panel._resizeStartY or y)) / scale
            local newW = math.max(PANEL_MIN_W, math.min(PANEL_MAX_W, (panel._resizeStartW or PANEL_MIN_W) + dx))
            local minH = GetCurrentPanelMinHeight(panel)
            local newH = math.max(minH, math.min(PANEL_MAX_H, (panel._resizeStartH or minH) - dy))
            panel._autoSizingHeight = true
            panel:SetSize(newW, newH)
            panel._autoSizingHeight = false
            if EL.LayoutPanel then EL:LayoutPanel() end
        end)
    end)
    panel.resize:SetScript("OnMouseUp", function(self)
        self:SetScript("OnUpdate", nil)
        panel._userSizing = false
        panel._resizeStartW, panel._resizeStartH = nil, nil
        panel._resizeStartX, panel._resizeStartY = nil, nil
        ClampPanelSize(panel)
        EL.db.settings.panel.width = math.floor(panel:GetWidth() or PANEL_MIN_W)
        EL.db.settings.panel.height = math.floor(panel:GetHeight() or PANEL_MIN_H)
        if not EL.db.settings.panel.charactersCollapsed then
            EL.db.settings.panel.expandedHeight = EL.db.settings.panel.height
        end
        SaveFramePoint(panel, EL.db.settings.panel)
        if EL.LayoutPanel then EL:LayoutPanel() end
    end)
    panel.resize.tex = panel.resize:CreateTexture(nil, "ARTWORK")
    panel.resize.tex:SetAllPoints()
    panel.resize.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    panel.resize.tex:SetAlpha(0.35)

    self:CreateSettingsPanel(panel)
    self:ApplyDisplaySettings()
    SetFramePointFromDB(panel, s)
    self:LayoutPanel()
end

function EL:UpdateSortHeaders()
    local p = self.panel
    if not p or not p.header then return end
    local sort = self:GetSortSettings()
    local active = sort.key or "character"
    local arrow = sort.ascending ~= false and "  ^" or "  v"
    local map = {
        character = p.header.name,
        prof = p.header.prof,
        conc = p.header.conc,
        mulch = p.header.mulch,
    }
    for key, fs in pairs(map) do
        fs:SetText((HEADER_LABELS[key] or key) .. (key == active and arrow or ""))
        local btnName = key == "character" and "nameButton" or (key .. "Button")
        local btn = p.header[btnName]
        if key == active then
            fs:SetTextColor(0.92, 0.78, 0.50)
            if btn and btn.bg then btn.bg:SetColorTexture(0.78, 0.66, 0.46, 0.10) end
        else
            fs:SetTextColor(0.78, 0.84, 0.92)
            if btn and btn.bg then btn.bg:SetColorTexture(1, 0.72, 0.22, 0) end
        end
    end
end

function EL:ShouldShowMulchColumn(rows)
    if not (self.db and self.db.resources and self.db.resources.mulch) then return false end
    if rows then
        for _, entry in ipairs(rows) do
            local key = entry and entry.key
            if key and not self:IsCharacterHidden(key) and self:HasImbuedMulchAccess(self.db.resources.mulch[key]) then
                return true
            end
        end
        return false
    end
    for key, data in pairs(self.db.resources.mulch or {}) do
        if key and not self:IsCharacterHidden(key) and self:HasImbuedMulchAccess(data) then
            return true
        end
    end
    return false
end


local function SetPanelHeightKeepTopLeft(panel, height, settings)
    if not panel then return end
    local left = panel:GetLeft()
    local top = panel:GetTop()

    panel._autoSizingHeight = true
    panel:SetHeight(height)

    -- Resizing a centered/middle-anchored frame can make it appear to move.
    -- Re-anchor by the current top-left corner so collapse/expand only changes
    -- the bottom edge of the EmberLedger window.
    if left and top then
        panel:ClearAllPoints()
        panel:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
        if settings then
            SaveFramePoint(panel, settings)
        end
    end

    panel._autoSizingHeight = false
end

function EL:AutoSizePanelHeight(reason)
    local p = self.panel
    if not p or p._autoSizingHeight or not (self.db and self.db.settings and self.db.settings.panel) then return end
    local settings = self.db.settings.panel
    local rows = self.GetDashboardRows and self:GetDashboardRows() or {}
    local charShown = settings.charactersShown ~= false
    local charCollapsed = settings.charactersCollapsed and true or false
    local sessionShown = self.db.settings.session and self.db.settings.session.shown ~= false
    local sessionCollapsed = settings.sessionCollapsed and true or false

    -- Only section toggles should change the panel height automatically.
    -- Regular data refreshes should not fight manual resizing.
    if not reason then return end

    local topPadding = 58
    local headerH = charShown and (charCollapsed and 30 or 66) or 0
    local rowCount = (charShown and not charCollapsed) and math.min(PANEL_DEFAULT_VISIBLE_ROWS, math.max(0, #rows)) or 0
    local rowH = rowCount * 27
    local emptyH = (charShown and not charCollapsed and #rows == 0) and 46 or 0
    local sessionH = sessionShown and (sessionCollapsed and SESSION_COLLAPSED_H or SESSION_EXPANDED_H) or 0
    local actionBarShown = settings.actionBarShown ~= false
    local actionBarH = actionBarShown and ACTION_BAR_H or 0
    local bottomPadding = actionBarShown and 42 or 30
    local compactDesired = topPadding + headerH + rowH + emptyH + sessionH + actionBarH + bottomPadding
    compactDesired = math.max(PANEL_MIN_H, math.min(PANEL_MAX_H, compactDesired))

    local current = math.max(PANEL_MIN_H, math.min(PANEL_MAX_H, p:GetHeight() or PANEL_MIN_H))
    local target = current
    local bothCollapsed = (not charShown or charCollapsed) and (not sessionShown or sessionCollapsed)

    if bothCollapsed then
        -- True compact mode: when both sections are closed, ignore any remembered
        -- expanded height so the frame does not keep a large empty bottom area.
        target = compactDesired
    elseif reason == "expandCharacter" then
        -- Restore the user's last useful expanded height so the character table
        -- shows more than a few rows immediately after reopening.
        local remembered = tonumber(settings.expandedHeight) or tonumber(settings.height) or 0
        target = math.max(compactDesired, remembered, 420)
    elseif reason == "collapseCharacter" then
        target = compactDesired
    elseif reason == "expandSession" then
        -- Keep the character section height unchanged. Expanding the session
        -- grows only the bottom edge by the session body delta.
        local sessionDelta = SESSION_EXPANDED_H - SESSION_COLLAPSED_H -- expanded session height minus collapsed header height
        if not charCollapsed then
            target = math.max(compactDesired, current + sessionDelta)
        else
            target = compactDesired
        end
    elseif reason == "sectionToggle" then
        target = compactDesired
    elseif reason == "collapseSession" then
        -- Keep the character section height unchanged. Collapsing the session
        -- removes only the session body delta, instead of recalculating visible
        -- character rows and accidentally squeezing the list.
        local sessionDelta = SESSION_EXPANDED_H - SESSION_COLLAPSED_H
        if not charCollapsed then
            target = math.max(compactDesired, current - sessionDelta)
        else
            target = compactDesired
        end
    else
        target = compactDesired
    end

    target = math.max(GetCurrentPanelMinHeight(p), math.min(PANEL_MAX_H, target))
    if math.abs(current - target) > 2 then
        SetPanelHeightKeepTopLeft(p, target, settings)
        settings.height = target
        if not charCollapsed and target >= PANEL_EXPANDED_MIN_H then settings.expandedHeight = target end
        if self.LayoutPanel then self:LayoutPanel() end
    end
end

function EL:LayoutPanel()
    local p = self.panel
    if not p or not p.header or not p.scroll or not p.content then return end
    ClampPanelSize(p)

    local w, h = p:GetWidth(), p:GetHeight()
    local settings = self.db and self.db.settings and self.db.settings.panel or {}
    local charShown = settings.charactersShown ~= false
    local charCollapsed = settings.charactersCollapsed and true or false
    local sessionShown = self.db and self.db.settings and self.db.settings.session and self.db.settings.session.shown ~= false
    local sessionCollapsed = settings.sessionCollapsed and true or false
    local actionBarShown = settings.actionBarShown ~= false
    local sessionH = sessionShown and (sessionCollapsed and SESSION_COLLAPSED_H or SESSION_EXPANDED_H) or 0

    if p.characterToggle then
        p.characterToggle:ClearAllPoints()
        p.characterToggle.text:SetText(charCollapsed and ">" or "v")
    end

    if p.actionBar then
        p.actionBar:ClearAllPoints()
        p.actionBar:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 12, 28)
        p.actionBar:SetPoint("BOTTOMRIGHT", p, "BOTTOMRIGHT", -14, 28)
        p.actionBar:SetHeight(actionBarShown and ACTION_BAR_H or 1)
        p.actionBar:SetShown(actionBarShown)
    end

    if p.sessionPanel then
        p.sessionPanel:SetHeight(sessionH > 0 and sessionH or 1)
        p.sessionPanel:ClearAllPoints()
        p.sessionPanel:SetPoint("LEFT", p, "LEFT", 14, 0)
        p.sessionPanel:SetPoint("RIGHT", p, "RIGHT", -14, 0)
        p.sessionPanel:SetShown(sessionShown)
    end

    p.header:ClearAllPoints()
    p.header:SetPoint("TOPLEFT", p, "TOPLEFT", 14, -58)
    p.header:SetPoint("TOPRIGHT", p, "TOPRIGHT", -14, -58)

    if p.characterToggle then
        p.characterToggle:SetPoint("LEFT", p.header, "LEFT", 6, 0)
        p.characterToggle:SetFrameLevel((p.header:GetFrameLevel() or 1) + 5)
    end

    if not charShown then
        p.header:Hide()
        p.scroll:Hide()
        if p.empty then p.empty:Hide() end
        if sessionShown and p.sessionPanel then
            p.sessionPanel:SetPoint("TOPLEFT", p, "TOPLEFT", 14, -58)
            p.sessionPanel:SetPoint("TOPRIGHT", p, "TOPRIGHT", -14, -58)
        end
    elseif charCollapsed then
        p.header:Show()
        p.scroll:Hide()
        if p.empty then p.empty:Hide() end
        if sessionShown and p.sessionPanel then
            p.sessionPanel:SetPoint("TOPLEFT", p.header, "BOTTOMLEFT", 0, -8)
            p.sessionPanel:SetPoint("RIGHT", p, "RIGHT", -14, 0)
        end
        if p.header.name then
            p.header.name:SetText("Characters")
            AnchorColumnText(p.header.name, p.header, 34, 160, "LEFT")
        end
        if p.header.prof then p.header.prof:Hide() end
        if p.header.conc then p.header.conc:Hide() end
        if p.header.mulch then p.header.mulch:Hide() end
        for _, name in ipairs({"nameButton", "profButton", "concButton", "mulchButton"}) do
            if p.header[name] then p.header[name]:Hide() end
        end
        for _, sep in ipairs(p.header.separators or {}) do sep:Hide() end
    else
        p.header:Show()
        p.scroll:Show()
        if p.header.prof then p.header.prof:Show() end
        if p.header.conc then p.header.conc:Show() end
        if p.header.nameButton then p.header.nameButton:Show() end
        if p.header.profButton then p.header.profButton:Show() end
        if p.header.concButton then p.header.concButton:Show() end

        local headerW = math.max(1, w - 36)
        local showMulch = self:ShouldShowMulchColumn()
        p.showMulchColumn = showMulch
        local cols = GetColumnLayout(headerW, showMulch)
        AnchorColumnText(p.header.name, p.header, cols.nameX + 26, math.max(34, cols.nameW - 26), "LEFT")
        AnchorColumnText(p.header.prof, p.header, cols.profX, cols.profW, "CENTER")
        AnchorColumnText(p.header.conc, p.header, cols.concX, cols.concW, "CENTER")
        AnchorColumnText(p.header.mulch, p.header, cols.mulchX, cols.mulchW, "CENTER")
        p.header.mulch:SetShown(showMulch)

        p.header.nameButton:ClearAllPoints()
        p.header.nameButton:SetPoint("LEFT", p.header, "LEFT", cols.nameX + 24, 0)
        p.header.nameButton:SetSize(math.max(34, cols.nameW - 24), 32)

        p.header.profButton:ClearAllPoints()
        p.header.profButton:SetPoint("LEFT", p.header, "LEFT", cols.profX, 0)
        p.header.profButton:SetSize(cols.profW, 32)

        p.header.concButton:ClearAllPoints()
        p.header.concButton:SetPoint("LEFT", p.header, "LEFT", cols.concX, 0)
        p.header.concButton:SetSize(cols.concW, 32)

        p.header.mulchButton:ClearAllPoints()
        p.header.mulchButton:SetPoint("LEFT", p.header, "LEFT", cols.mulchX, 0)
        p.header.mulchButton:SetSize(math.max(1, cols.mulchW), 32)
        p.header.mulchButton:SetShown(showMulch)

        local sepPositions = { cols.profX - 6, cols.concX - 6 }
        if showMulch then table.insert(sepPositions, cols.mulchX - 6) end
        for i, x in ipairs(sepPositions) do
            local sep = p.header.separators[i]
            if not sep then
                sep = p.header:CreateTexture(nil, "BORDER")
                p.header.separators[i] = sep
            end
            sep:ClearAllPoints()
            sep:SetWidth(1)
            sep:SetPoint("TOPLEFT", p.header, "TOPLEFT", x, -4)
            sep:SetPoint("BOTTOMLEFT", p.header, "BOTTOMLEFT", x, 4)
            sep:SetColorTexture(0.82, 0.74, 0.58, 0.08)
            sep:Show()
        end
        for i = #sepPositions + 1, #(p.header.separators or {}) do
            p.header.separators[i]:Hide()
        end

        p.scroll:ClearAllPoints()
        p.scroll:SetPoint("TOPLEFT", p.header, "BOTTOMLEFT", 0, -4)
        if sessionShown and p.sessionPanel then
            if p.actionBar and actionBarShown then
                p.sessionPanel:SetPoint("BOTTOMLEFT", p.actionBar, "TOPLEFT", 0, 8)
                p.sessionPanel:SetPoint("BOTTOMRIGHT", p.actionBar, "TOPRIGHT", 0, 8)
            else
                p.sessionPanel:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 12, 34)
                p.sessionPanel:SetPoint("BOTTOMRIGHT", p, "BOTTOMRIGHT", -14, 34)
            end
            p.scroll:SetPoint("BOTTOMRIGHT", p.sessionPanel, "TOPRIGHT", -2, 6)
        else
            if p.actionBar and actionBarShown then
                p.scroll:SetPoint("BOTTOMRIGHT", p.actionBar, "TOPRIGHT", -2, 8)
            else
                p.scroll:SetPoint("BOTTOMRIGHT", p, "BOTTOMRIGHT", -14, 34)
            end
        end
        p.content:SetWidth(math.max(1, p.scroll:GetWidth()))
        self:UpdateSortHeaders()
    end

    self:RefreshPanel()
end

function EL:GetRow(i)
    local p = self.panel
    if not p.rows[i] then
        local row = CreateFrame("Button", nil, p.content)
        row:SetHeight(23)
        row.bg = row:CreateTexture(nil, "BACKGROUND")
        row.bg:SetAllPoints()
        row.sep = row:CreateTexture(nil, "BORDER")
        row.sep:SetHeight(1)
        row.sep:SetPoint("BOTTOMLEFT", 0, 0)
        row.sep:SetPoint("BOTTOMRIGHT", 0, 0)
        row.sep:SetColorTexture(0.95, 0.82, 0.42, 0.16)
        row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        row.name:SetJustifyH("LEFT")
        row.prof = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        row.prof:SetJustifyH("CENTER")
        row.conc = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        row.conc:SetJustifyH("RIGHT")
        row.mulch = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        row.mulch:SetJustifyH("RIGHT")
        row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        row:SetScript("OnClick", function(self, button)
            if button == "RightButton" and self.charKey then
                local char = EL.db.characters[self.charKey]
                local displayName = (char and (char.displayName or char.name)) or self.charKey
                GameTooltip:Hide()

                if IsShiftKeyDown and IsShiftKeyDown() then
                    EL:ResetCharacterData(self.charKey)
                else
                    EL:SetCharacterHidden(self.charKey, true)
                    EL:RequestUpdate()
                    EL:Print("Hidden: " .. tostring(displayName))
                end
            end
        end)
        row:SetScript("OnEnter", function(self)
            if self.hover then self.hover:Show() end
            EL:ShowRowTooltip(self)
        end)
        row:SetScript("OnLeave", function(self)
            if self.hover then self.hover:Hide() end
            GameTooltip:Hide()
        end)
        row.hover = row:CreateTexture(nil, "HIGHLIGHT")
        row.hover:SetAllPoints()
        row.hover:SetColorTexture(1.00, 0.82, 0.24, 0.12)
        row.hover:Hide()
        p.rows[i] = row
    end
    return p.rows[i]
end

function EL:RefreshPanel()
    local p = self.panel
    if not p then return end
    local bestConc = self:GetHighestConcentrationSummary()
    local nextMulch = self:GetNextMulchSummary()
    local concText = bestConc and (bestConc.displayName .. " " .. (bestConc.abbrev or "Prof") .. " " .. bestConc.quantity .. "/" .. bestConc.maxQuantity) or "Conc. N/A"
    local mulchText = nextMulch and ("Imbued Mulch " .. self:FormatCountdown(nextMulch.remaining)) or "Imbued Mulch N/A"
    if p.summary then
        p.summary:SetText("")
        p.summary:Hide()
    end
    local hiddenCount = 0
    for _, hidden in pairs(self.db.settings.hiddenCharacters or {}) do
        if hidden then hiddenCount = hiddenCount + 1 end
    end
    if p.restore then
        p.restore:SetShown(hiddenCount > 0)
        p.restore:SetText(hiddenCount > 0 and ("Restore (" .. hiddenCount .. ")") or "Restore")
    end

    local charCollapsed = self.db and self.db.settings and self.db.settings.panel and self.db.settings.panel.charactersCollapsed
    if charCollapsed then
        if p.rows then
            for i = 1, #p.rows do p.rows[i]:Hide() end
        end
        if p.empty then p.empty:Hide() end
        self:RefreshSessionPanel()
        return
    end

    local allRows = self:GetCharacterRows()
    local rows = {}
    for _, entry in ipairs(allRows) do
        if not self:IsCharacterHidden(entry.key) then
            table.insert(rows, entry)
        end
    end
    self:SortDashboardRows(rows)
    self:UpdateSortHeaders()
    local now = time()
    local rowH, gap = 23, 0
    local width = math.max(1, p.scroll and p.scroll:GetWidth() or p:GetWidth() - 40)
    local showMulch = self:ShouldShowMulchColumn(rows)
    if p.showMulchColumn ~= showMulch then
        p.showMulchColumn = showMulch
        self:LayoutPanel()
        return
    end
    local cols = GetColumnLayout(width, showMulch)
    p.content:SetWidth(width)

    for i, entry in ipairs(rows) do
        local row = self:GetRow(i)
        local charKey, char = entry.key, entry.char
        local concEntries = self:GetConcentrationEntriesForCharacter(charKey)
        local concData = self:GetBestConcentrationForCharacter(charKey, now)
        local mulchData = self.db.resources.mulch and self.db.resources.mulch[charKey]
        local profValue = "N/A"
        local concValue = "N/A"
        if concData then
            local q = self:GetEstimatedConcentration(concData, now) or 0
            profValue = self:GetProfessionAbbreviation(concData)
            if #concEntries > 1 then profValue = profValue .. "+" .. tostring(#concEntries - 1) end
            concValue = tostring(q) .. "/" .. tostring(concData.maxQuantity or self.CONCENTRATION_MAX_DEFAULT)
        end
        local mulchValue = "N/A"
        if self:HasImbuedMulchAccess(mulchData) then
            local remain = math.max(0, (tonumber(mulchData.readyAt) or 0) - now)
            mulchValue = remain <= 0 and (READY_ICON .. " Ready") or self:FormatCountdown(remain)
        end

        row:SetWidth(width)
        row:SetPoint("TOPLEFT", p.content, "TOPLEFT", 0, -((i - 1) * (rowH + gap)))
        AnchorColumnText(row.name, row, cols.nameX, cols.nameW, "LEFT")
        AnchorColumnText(row.prof, row, cols.profX, cols.profW, "CENTER")
        AnchorColumnText(row.conc, row, cols.concX, cols.concW, "RIGHT")
        AnchorColumnText(row.mulch, row, cols.mulchX, math.max(1, cols.mulchW), "RIGHT")
        row.mulch:SetShown(showMulch)

        row.charKey = charKey
        row.concData = concData
        row.concEntries = concEntries
        row.mulchData = mulchData
        row.name:SetText(char.displayName or charKey)
        local r, g, b = self:GetClassColor(char.class)
        row.name:SetTextColor(r, g, b)
        row.prof:SetText(profValue)
        row.prof:SetTextColor(0.88, 0.86, 0.76)
        row.conc:SetText(concValue)
        if concData then
            local cq = self:GetEstimatedConcentration(concData, now) or 0
            local cr, cg, cb = self:GetConcentrationColor(cq, concData.maxQuantity or self.CONCENTRATION_MAX_DEFAULT)
            row.conc:SetTextColor(cr, cg, cb)
        else
            row.conc:SetTextColor(0.7, 0.7, 0.7)
        end
        if row.full then row.full:Hide() end
        row.mulch:SetText(mulchValue)
        if self:HasImbuedMulchAccess(mulchData) then
            local remain = math.max(0, (tonumber(mulchData.readyAt) or 0) - now)
            local mr, mg, mb = self:GetMulchCountdownColor(remain)
            row.mulch:SetTextColor(mr, mg, mb)
        else
            row.mulch:SetTextColor(0.7, 0.7, 0.7)
        end
        local stripe = (i % 2 == 0) and 0.035 or 0
        row.bg:SetColorTexture(0.18 + stripe, 0.18 + stripe, 0.19 + stripe, 0.54)
        row:Show()
    end
    for i = #rows + 1, #p.rows do
        p.rows[i]:Hide()
    end
    if p.empty then
        p.empty:ClearAllPoints()
        p.empty:SetPoint("TOP", p.header, "BOTTOM", 0, -42)
        p.empty:SetShown(#rows == 0)
    end
    p.content:SetHeight(math.max(40, #rows * (rowH + gap)))
    self:RefreshSessionPanel()
end

function EL:UpdateButton()
    local b = self.button
    if not b then return end
    local display = self.db and self.db.settings and self.db.settings.display or {}
    local threshold = self.db and self.db.settings and self.db.settings.alerts and self.db.settings.alerts.concentrationThreshold or 360
    local concReady = self:GetConcentrationReadyCount(threshold)
    local mulchReady = self:GetMulchReadyCount()
    local nextMulch = self:GetNextMulchSummary()
    ApplyFrameOpacity(b, GetLauncherOpacity())
    if b.title then
        b.title:SetText("EmberLedger")
        b.title:SetTextColor(1.00, 0.82, 0.24)
        b.title:SetJustifyH("CENTER")
        b.title:SetShadowColor(0.00, 0.00, 0.00, 0.95)
        b.title:SetShadowOffset(1, -1)
    end

    if b.line1 then
        if display.showLauncherConc ~= false and concReady > 0 then
            b.line1:SetText("Conc Ready: " .. tostring(concReady))
            b.line1:SetTextColor(1.00, 0.82, 0.24)
            b.line1:Show()
        else
            b.line1:SetText("")
            b.line1:Hide()
        end
    end

    if b.line2 then
        if display.showLauncherMulch == false then
            b.line2:SetText("")
            b.line2:Hide()
        elseif nextMulch then
            if mulchReady > 0 then
                b.line2:SetText("Mulch Ready: " .. tostring(mulchReady))
                b.line2:SetTextColor(0.35, 1.00, 0.35)
            else
                b.line2:SetText("Mulch " .. self:FormatCountdown(nextMulch.remaining))
                b.line2:SetTextColor(self:GetMulchCountdownColor(nextMulch.remaining))
            end
            b.line2:Show()
        else
            b.line2:SetText("Mulch N/A")
            b.line2:SetTextColor(0.52, 0.60, 0.68)
            b.line2:Show()
        end
    end

    local sessionShown = self.db and self.db.settings and self.db.settings.session and self.db.settings.session.shown ~= false
    local showSessionGold = sessionShown and display.showLauncherSession ~= false
    local showSessionTotal = sessionShown and display.showLauncherSessionTotal ~= false
    local showSessionTime = sessionShown and display.showLauncherSessionTime ~= false
    local sdb = self.GetSessionDB and self:GetSessionDB() or {}
    if b.line3 then
        if showSessionGold then
            b.line3:SetText(self:FormatMoneyText(self:GetSessionGoldPerHour()) .. "/hr")
            b.line3:SetTextColor(0.86, 0.84, 0.76)
            b.line3:Show()
        else
            b.line3:SetText("")
            b.line3:Hide()
        end
    end
    if b.line4 then
        if showSessionTotal then
            b.line4:SetText("Total: " .. self:FormatMoneyText(sdb.totalSilver or 0))
            b.line4:SetTextColor(0.86, 0.84, 0.76)
            b.line4:Show()
        else
            b.line4:SetText("")
            b.line4:Hide()
        end
    end
    if b.line5 then
        if showSessionTime then
            b.line5:SetText("Time: " .. FormatSessionTime(self:GetSessionElapsedSeconds()))
            b.line5:SetTextColor(0.78, 0.78, 0.72)
            b.line5:Show()
        else
            b.line5:SetText("")
            b.line5:Hide()
        end
    end

    local textW = math.max(GetTextWidth(b.title), GetTextWidth(b.line1), GetTextWidth(b.line2), b.line3 and GetTextWidth(b.line3) or 0, b.line4 and GetTextWidth(b.line4) or 0, b.line5 and GetTextWidth(b.line5) or 0)
    local targetW = math.ceil(math.max(142, textW + 28))
    local visibleLines = 1 + ((b.line1 and b.line1:IsShown()) and 1 or 0) + ((b.line2 and b.line2:IsShown()) and 1 or 0) + ((b.line3 and b.line3:IsShown()) and 1 or 0) + ((b.line4 and b.line4:IsShown()) and 1 or 0) + ((b.line5 and b.line5:IsShown()) and 1 or 0)
    local targetH = math.max(50, 28 + (visibleLines * 15))
    if math.abs((b:GetWidth() or 0) - targetW) > 2 or math.abs((b:GetHeight() or 0) - targetH) > 2 then
        b:SetSize(targetW, targetH)
    end
    if self.settingsPanel and self.settingsPanel:IsShown() then self:RefreshSettingsPanel() end
end

function EL:ApplyPanelScale()
    if not self.panel then return end
    local scale = tonumber(self.db.settings.panel.scale) or 1
    scale = math.max(PANEL_MIN_SCALE, math.min(PANEL_MAX_SCALE, scale))
    self.db.settings.panel.scale = scale
    self.panel:SetScale(scale)
end

function EL:AdjustPanelScale(delta)
    local current = tonumber(self.db.settings.panel.scale) or 1
    self.db.settings.panel.scale = math.max(PANEL_MIN_SCALE, math.min(PANEL_MAX_SCALE, current + (delta or 0)))
    self:ApplyPanelScale()
    self:Print("Window scale: " .. string.format("%.2f", self.db.settings.panel.scale))
end

function EL:ShowPanelFromSavedState()
    if not self.panel then return end
    if not self.db.settings.panel.detached and self.button then
        self.panel:ClearAllPoints()
        self.panel:SetPoint("TOPLEFT", self.button, "BOTTOMLEFT", 0, -8)
    else
        SetFramePointFromDB(self.panel, self.db.settings.panel)
    end
    self:ApplyPanelScale()
    self:RefreshPanel()
    self.panel:Show()
end

function EL:TogglePanel()
    if not self.panel then return end
    if self.panel:IsShown() then
        self.panel:Hide()
        return
    end
    self:ShowPanelFromSavedState()
end

function EL:ToggleLauncherLock()
    local s = self.db.settings.button
    s.locked = not s.locked
    self:Print("Launcher " .. (s.locked and "locked. Hold Shift and drag to move it." or "unlocked."))
end

function EL:ResetWindowPositions()
    self.db.settings.panel.detached = false
    self.db.settings.button.point = "CENTER"
    self.db.settings.button.relativePoint = "CENTER"
    self.db.settings.button.x = 0
    self.db.settings.button.y = 120
    if self.button then SetFramePointFromDB(self.button, self.db.settings.button) end
    if self.panel then self.panel:ClearAllPoints(); self.panel:SetPoint("CENTER") end
    self:Print("Window positions reset.")
end

function EL:ShowButtonTooltip(owner)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetText("EmberLedger", 1, 0.82, 0.24)
    local bestConc = self:GetHighestConcentrationSummary()
    local nextMulch = self:GetNextMulchSummary()
    if bestConc then
        GameTooltip:AddDoubleLine("Highest concentration", bestConc.displayName .. " " .. (bestConc.abbrev or "Prof") .. " - " .. bestConc.quantity .. "/" .. bestConc.maxQuantity, 0.62, 0.78, 0.92, 1, 1, 1)
    else
        GameTooltip:AddLine("Highest concentration: N/A", 0.7, 0.7, 0.7)
    end
    if nextMulch then
        GameTooltip:AddDoubleLine("Closest Imbued Mulch", nextMulch.displayName .. " - " .. self:FormatCountdown(nextMulch.remaining), 0.62, 0.78, 0.92, 1, 1, 1)
    else
        GameTooltip:AddLine("Closest Imbued Mulch: N/A", 0.7, 0.7, 0.7)
    end
    local total, concCount, herbCount, hiddenCount = 0, 0, 0, 0
    for key in pairs(self.db.characters or {}) do
        total = total + 1
        if self:IsCharacterHidden(key) then hiddenCount = hiddenCount + 1 end
    end
    for _, d in pairs(self.db.resources.concentration or {}) do if not self:IsCharacterHidden(d.charKey) then concCount = concCount + 1 end end
    for _, d in pairs(self.db.resources.mulch or {}) do if self:HasImbuedMulchAccess(d) and not self:IsCharacterHidden(d.charKey) then herbCount = herbCount + 1 end end
    GameTooltip:AddLine(" ")
    GameTooltip:AddDoubleLine("Tracked characters", tostring(total), 0.8, 0.8, 0.8, 1, 1, 1)
    GameTooltip:AddDoubleLine("Hidden characters", tostring(hiddenCount), 0.8, 0.8, 0.8, 1, 1, 1)
    GameTooltip:AddDoubleLine("Visible concentration entries", tostring(concCount), 0.8, 0.8, 0.8, 1, 1, 1)
    GameTooltip:AddDoubleLine("Imbued Mulch access", tostring(herbCount), 0.8, 0.8, 0.8, 1, 1, 1)
    local s = self:GetSessionDB()
    GameTooltip:AddLine(" ")
    GameTooltip:AddDoubleLine("Session value", self:FormatMoneyText(s.totalSilver or 0), 0.95, 0.62, 0.26, 1, 1, 1)
    GameTooltip:AddDoubleLine("Gold/hour", self:FormatMoneyText(self:GetSessionGoldPerHour()) .. "/hr", 0.95, 0.62, 0.26, 1, 1, 1)
    GameTooltip:AddDoubleLine("Session status", s.isPaused and "Paused" or "Running", 0.95, 0.62, 0.26, 1, 1, 1)
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Left-click: open dashboard", 0.7, 0.7, 0.7)
    GameTooltip:AddLine("Right-click: lock/unlock launcher", 0.7, 0.7, 0.7)
    GameTooltip:AddLine("Shift-drag: move while locked", 0.7, 0.7, 0.7)
    GameTooltip:Show()
end

function EL:ShowRowTooltip(row)
    if not row then return end
    local char = self.db.characters[row.charKey or ""]
    GameTooltip:SetOwner(row, "ANCHOR_RIGHT")
    GameTooltip:SetText((char and char.displayName) or row.charKey or "Character", 1, 0.82, 0.24)
    if row.concEntries and #row.concEntries > 0 then
        GameTooltip:AddLine("Concentration", 0.62, 0.78, 0.92)
        for _, data in ipairs(row.concEntries) do
            local label = string.format("%s - %s", self:GetProfessionAbbreviation(data), self:GetCleanProfessionName(data.professionName))
            local value = tostring(self:GetEstimatedConcentration(data)) .. "/" .. tostring(data.maxQuantity or self.CONCENTRATION_MAX_DEFAULT) .. " (" .. self:GetConcentrationFullIn(data) .. ")"
            GameTooltip:AddDoubleLine(label, value, 0.62, 0.78, 0.92, 1, 1, 1)
        end
    else
        GameTooltip:AddLine("Concentration: N/A", 0.7, 0.7, 0.7)
    end
    if self:HasImbuedMulchAccess(row.mulchData) then
        local remain = math.max(0, (tonumber(row.mulchData.readyAt) or 0) - time())
        GameTooltip:AddDoubleLine("Imbued Mulch", self:FormatCountdown(remain), 0.95, 0.62, 0.26, 1, 1, 1)
        GameTooltip:AddDoubleLine("Item", row.mulchData.itemName or "Imbued Mulch", 0.95, 0.62, 0.26, 1, 1, 1)
        GameTooltip:AddDoubleLine("In bags", tostring(row.mulchData.itemCount or 0), 0.95, 0.62, 0.26, 1, 1, 1)
    else
        GameTooltip:AddLine("Imbued Mulch: N/A", 0.7, 0.7, 0.7)
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Right-click: hide this character", 0.7, 0.7, 0.7)
    GameTooltip:AddLine("Shift-right-click: reset this character's data", 0.95, 0.62, 0.26)
    GameTooltip:Show()
end
