EmberLedger v0.9.2 Beta
========================

EmberLedger is a World of Warcraft profession utility addon focused on alt readiness, Imbued Mulch tracking, and gathering session value tracking.

This build is intended as a beta testing build after the v0.9 layout cleanup. The current goal is stability, polish, and bug reporting rather than adding new features.

Notable v0.9.2 changes:
- Centralized UI sizing constants are now used by the UI layer.
- Saved settings are normalized on load to prevent bad opacity, scale, threshold, stale collapse, or window-size values from causing odd layouts.
- Lock Windows now clearly displays Lock: On or Lock: Off in the options panel.
- /el lock and /el unlock now control global window locking.
- Reset Windows resets launcher, tracking window, session window, and visible options panel placement.
- Launcher Session rate toggle label is clearer.

Core Features
-------------
- Tracks profession concentration across characters.
- Shows concentration readiness alerts based on a configurable threshold.
- Tracks confirmed Imbued Mulch capability and cooldowns.
- Tracks gathering session value, total gold, gold per hour, session time, and gathered loot entries.
- Supports compact launcher display with configurable lines.
- Includes optional convenience action buttons for supported items/spells.
- Includes configurable window opacity, launcher opacity, window scale, concentration threshold, and visible sections.

Window Layout
-------------
EmberLedger now uses two independent windows:

1. Main EmberLedger Window
   - Character readiness table.
   - Profession concentration.
   - Imbued Mulch timers.
   - Convenience/action buttons.
   - Options button.

2. Session Window
   - Session time.
   - Total gold value.
   - Gold per hour.
   - Four-line chronological loot feed.
   - Mousewheel scrolling over the loot feed.
   - Pause and Reset buttons.

The launcher opens both windows by default. The main window and session window can then be closed independently.

Pricing Support
---------------
EmberLedger can use available pricing data from supported auction/pricing addons when present.
If no pricing source is available for an item, the item may still appear but its value may be missing or shown as zero.

Basic Use
---------
- Left-click the launcher to show/hide both EmberLedger windows.
- Right-click the launcher to lock/unlock launcher movement.
- Drag the launcher, main window, or session window to reposition them.
- Use the Options button to adjust display settings.
- Use the Characters section to review concentration and Imbued Mulch status.
- Use the standalone Session window to review gathered item value and session gold per hour.
- Hover the session item list and use the mouse wheel to scroll when more than four loot entries are tracked.

Slash Commands
--------------
/el
/ember
/emberledger

Window Commands
---------------
/el main       Toggle the main EmberLedger window.
/el session    Toggle the standalone session window.
/el settings   Open options.

Session Commands
----------------
/el session start
/el session pause
/el session reset
/el debug

Notes and Known Limitations
---------------------------
- Session data resets automatically on login/reload and begins tracking immediately.
- EmberLedger baselines existing bag contents at startup so existing materials are not counted as newly gathered.
- Secure action buttons defer visibility/layout refreshes while in combat due to Blizzard protected-frame restrictions.
- Debug logging can be toggled with /el debug for bug reports.
- Convenience buttons only appear when the related item/toy/spell is detected as available.
- Imbued Mulch tracking requires confirmed access, not merely having old saved data.
- Characters without concentration or confirmed Imbued Mulch capability are hidden from the active dashboard.

Installation
------------
1. Exit World of Warcraft completely.
2. Delete any old EmberLedger folder from Interface/AddOns.
3. Extract the EmberLedger folder into:
   World of Warcraft/_retail_/Interface/AddOns/
4. Restart World of Warcraft.
5. Enable EmberLedger on the AddOns screen.

Recommended Testing Checklist
-----------------------------
- Confirm the launcher remembers position and display settings.
- Confirm the main window and session window remember their positions.
- Confirm both windows remember whether they were open or closed.
- Confirm /el opens/closes both windows.
- Confirm /el main and /el session toggle their respective windows.
- Confirm concentration threshold alerts work at your chosen value.
- Confirm Imbued Mulch only appears for characters that can actually use it.
- Confirm session tracking does not count items already in bags after reload.
- Confirm item list scrolling works after collecting more than four tracked entries.
- Confirm convenience buttons do not cause protected action errors.
- Optional: use /el debug while testing session item filtering or action-button issues.
