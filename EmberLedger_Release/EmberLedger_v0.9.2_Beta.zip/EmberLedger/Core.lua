local addonName, EL = ...
_G.EmberLedger = EL

EL.name = addonName or "EmberLedger"
EL.version = C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(addonName, "Version") or "0.9.2 Beta"
EL.frame = CreateFrame("Frame")
EL.modules = {}
EL.DB_KEY_SEP = "\031"
EL.CONCENTRATION_MAX_DEFAULT = 1000
EL.CONCENTRATION_RATE_PER_HOUR = 10
EL.IMBUED_MULCH_ITEM_ID = 238388
EL.TRADEGOODS_CLASS = Enum.ItemClass and Enum.ItemClass.Tradegoods or 7
EL.CONSUMABLE_CLASS = Enum.ItemClass and Enum.ItemClass.Consumable or 0
EL.SESSION_DEDUPE_SECONDS = 5
EL.MULCH_ITEM_ID = EL.IMBUED_MULCH_ITEM_ID
EL.HERBALISM_ID = 182

EL.UI_CONSTANTS = {
    PANEL_MIN_W = 352,
    PANEL_MIN_H = 120,
    SESSION_MIN_W = 352,
    SESSION_EXPANDED_H = 166,
    SESSION_COLLAPSED_H = 36,
    ACTION_BAR_H = 36,
    SESSION_VISIBLE_ITEM_ROWS = 4,
    SESSION_ITEM_ROW_H = 18,
    PANEL_DEFAULT_VISIBLE_ROWS = 12,
    PANEL_EXPANDED_MIN_H = 300,
    PANEL_MAX_W = 900,
    PANEL_MAX_H = 720,
    PANEL_MIN_SCALE = 0.6,
    PANEL_MAX_SCALE = 1.4,
}

EL.DB_VERSION = 920

EL.PROFESSION_ABBREVIATIONS = {
    [164] = "BS",
    [165] = "LW",
    [171] = "ALCH",
    [182] = "HERB",
    [186] = "MIN",
    [197] = "TAIL",
    [202] = "ENG",
    [333] = "ENCH",
    [393] = "SKIN",
    [755] = "JC",
    [773] = "INS",
    [794] = "ARCH",
    [356] = "FISH",
    [185] = "COOK",
}

local defaults = {
    version = 920,
    characters = {},
    resources = {
        concentration = {},
        mulch = {},
    },
    settings = {
        sort = {
            key = "character",
            ascending = true,
        },
        button = {
            point = "CENTER",
            relativePoint = "CENTER",
            x = 0,
            y = 120,
            locked = false,
        },
        panel = {
            point = "CENTER",
            relativePoint = "CENTER",
            x = 0,
            y = 0,
            width = 540,
            height = 360,
            scale = 1,
            charactersCollapsed = false,
            sessionCollapsed = false,
            charactersShown = true,
            actionBarShown = true,
            windowOpen = false,
        },
        session = {
            shown = true,
            windowOpen = false,
            point = "CENTER",
            relativePoint = "CENTER",
            x = 260,
            y = 0,
            width = 352,
            height = 180,
            scale = 1,
            collapsed = false,
            pricingSource = "Auctionator",
            topItems = 50,
            trackTradegoods = true,
            trackFish = true,
        },
        alerts = {
            concentrationThreshold = 360,
        },
        display = {
            panelOpacity = 0.55,
            launcherOpacity = 0.50,
            sessionOpacity = 0.55,
            showLauncherConc = true,
            showLauncherMulch = true,
            showLauncherSession = true,
            showLauncherSessionTotal = true,
            showLauncherSessionTime = true,
        },
        hiddenCharacters = {},
        lockWindows = false,
        debug = false,
    },
}

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then
                dst[k] = {}
            end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

local function RemoveLegacySavedVariableFields(db)
    if type(db) ~= "table" then return end
    if type(db.settings) == "table" then
        db.settings.sortMode = nil
        if type(db.settings.button) == "table" then
            db.settings.button.width = nil
            db.settings.button.height = nil
        end
        if type(db.settings.panel) == "table" then
            db.settings.panel.detached = nil
            if type(db.settings.session) == "table" and db.settings.session.collapsed == nil then
                db.settings.session.collapsed = db.settings.panel.sessionCollapsed and true or false
            end
            db.settings.panel.sessionCollapsed = nil
        end
    end

    -- totalItems is no longer displayed and was a frequent source of legacy noise.
    -- Keep item/value data, but allow the aggregate count to be rebuilt later if needed.
    if type(db.session) == "table" then
        db.session.totalItems = nil
        db.session.legacyProjected = nil
        db.session.projected = nil
        db.session.wallet = nil
        db.session.goal = nil
    end
end

function EL:RunDatabaseCleanup(previousVersion)
    local current = tonumber(previousVersion) or tonumber(self.db and self.db.version) or 0
    if current < self.DB_VERSION then
        RemoveLegacySavedVariableFields(self.db)
        self.db.version = self.DB_VERSION
    end
end

local function ClampNumber(value, minValue, maxValue, fallback)
    value = tonumber(value)
    if value == nil then value = fallback end
    if minValue ~= nil and value < minValue then value = minValue end
    if maxValue ~= nil and value > maxValue then value = maxValue end
    return value
end

function EL:NormalizeDatabaseSettings()
    if type(self.db) ~= "table" or type(self.db.settings) ~= "table" then return end
    local settings = self.db.settings
    settings.display = settings.display or {}
    settings.alerts = settings.alerts or {}
    settings.panel = settings.panel or {}
    settings.session = settings.session or {}
    settings.button = settings.button or {}

    settings.display.panelOpacity = ClampNumber(settings.display.panelOpacity, 0.20, 1.00, 0.55)
    settings.display.launcherOpacity = ClampNumber(settings.display.launcherOpacity, 0.20, 1.00, 0.50)
    settings.display.sessionOpacity = ClampNumber(settings.display.sessionOpacity, 0.20, 1.00, 0.55)
    settings.alerts.concentrationThreshold = math.floor(ClampNumber(settings.alerts.concentrationThreshold, 0, self.CONCENTRATION_MAX_DEFAULT, 360))

    local ui = self.UI_CONSTANTS or {}
    local minScale = ui.PANEL_MIN_SCALE or 0.6
    local maxScale = ui.PANEL_MAX_SCALE or 1.4
    settings.panel.scale = ClampNumber(settings.panel.scale, minScale, maxScale, 1)
    settings.session.scale = ClampNumber(settings.session.scale, minScale, maxScale, 1)

    settings.panel.width = math.floor(ClampNumber(settings.panel.width, ui.PANEL_MIN_W or 352, ui.PANEL_MAX_W or 900, 352))
    settings.panel.height = math.floor(ClampNumber(settings.panel.height, ui.PANEL_MIN_H or 120, ui.PANEL_MAX_H or 720, 360))
    settings.session.width = math.floor(ClampNumber(settings.session.width, ui.SESSION_MIN_W or 352, ui.PANEL_MAX_W or 900, ui.SESSION_MIN_W or 352))
    settings.session.height = math.floor(ClampNumber(settings.session.height, 120, ui.PANEL_MAX_H or 720, 180))

    settings.panel.charactersCollapsed = false
    settings.session.collapsed = false
    settings.panel.sessionCollapsed = nil
end

function EL:Debug(msg)
    if self.db and self.db.settings and self.db.settings.debug then
        print("|cff9ecbffEmberLedger Debug:|r " .. tostring(msg))
    end
end

function EL:ToggleDebug()
    self.db.settings.debug = not self.db.settings.debug
    self:Print("Debug " .. (self.db.settings.debug and "enabled." or "disabled."))
end

function EL:IsCombatLocked()
    return InCombatLockdown and InCombatLockdown()
end

function EL:RequestActionBarRefresh()
    if self:IsCombatLocked() then
        self.pendingActionBarRefresh = true
        return
    end
    if self.UpdateActionBar then self:UpdateActionBar() end
end

function EL:FlushCombatDeferredWork()
    if self.pendingActionBarRefresh then
        self.pendingActionBarRefresh = nil
        if self.UpdateActionBar then self:UpdateActionBar() end
    end
    if self.pendingSecureLayout then
        self.pendingSecureLayout = nil
        if self.LayoutPanel then self:LayoutPanel() end
        if self.AutoSizePanelHeight then self:AutoSizePanelHeight("combatDeferred") end
        if self.RequestUpdate then self:RequestUpdate() end
    end
end

function EL:EnsureDB()
    if type(EmberLedgerDB) ~= "table" then
        EmberLedgerDB = {}
    end
    local previousVersion = tonumber(EmberLedgerDB.version) or 0
    CopyDefaults(defaults, EmberLedgerDB)
    self.db = EmberLedgerDB
    self:RunDatabaseCleanup(previousVersion)
    self:NormalizeDatabaseSettings()

    -- v0.8.2: internal collapse controls were removed when the character and
    -- session modules became independently toggled/windows. Clear old collapse
    -- state so stale SavedVariables cannot create blank panels after reload.
    local uiRefactorVersion = tonumber(self.db.uiRefactorVersion) or 0
    if uiRefactorVersion < 820 then
        self.db.settings = self.db.settings or {}
        self.db.settings.panel = self.db.settings.panel or {}
        self.db.settings.session = self.db.settings.session or {}
        self.db.settings.panel.charactersCollapsed = false
        self.db.settings.session.collapsed = false
        self.db.uiRefactorVersion = 820
    end

    -- v0.4.20: clear older Imbued Mulch capability flags that were based on
    -- generic Herbalism or stale saved data. Capability is now only trusted
    -- when it was confirmed by the stricter v2 check in Modules/Mulch.lua.
    local mulchVersion = tonumber(self.db.mulchCapabilityVersion) or 0
    if mulchVersion < 2 and self.db.resources and type(self.db.resources.mulch) == "table" then
        for _, data in pairs(self.db.resources.mulch) do
            if type(data) == "table" then
                data.confirmedImbuedMulchAccess = nil
                data.hasImbuedMulchAccess = false
                data.itemKnown = nil
                data.readyAt = nil
                data.confirmationSource = nil
                data.confirmationVersion = nil
            end
        end
        self.db.mulchCapabilityVersion = 2
    end

    -- v0.4.25: normalize launcher opacity default to 50% for the redesigned launcher/settings panel.
    local uiOptionsVersion = tonumber(self.db.uiOptionsVersion) or 0
    if uiOptionsVersion < 425 then
        self.db.settings = self.db.settings or {}
        self.db.settings.display = self.db.settings.display or {}
        self.db.settings.display.launcherOpacity = 0.50
        self.db.uiOptionsVersion = 425
    end

    -- v0.9.1: align standalone Session window width with the minimum Profession Tracking window width.
    -- Preserve intentionally wider user values, but pull old default-width saves down to the cleaner compact width.
    local sessionWidthVersion = tonumber(self.db.sessionWidthVersion) or 0
    if sessionWidthVersion < 910 then
        self.db.settings = self.db.settings or {}
        self.db.settings.session = self.db.settings.session or {}
        local session = self.db.settings.session
        if session.width == nil or tonumber(session.width) <= 360 then
            session.width = 352
        end
        self.db.sessionWidthVersion = 910
    end

    self:NormalizeDatabaseSettings()
    return EmberLedgerDB
end

function EL:GetRealm()
    return GetNormalizedRealmName() or GetRealmName() or "UnknownRealm"
end

function EL:GetCharacterKey(name, realm)
    name = name or UnitName("player") or "Unknown"
    realm = realm or self:GetRealm()
    return name .. "-" .. realm
end

function EL:GetCurrentCharacter()
    local key = self:GetCharacterKey()
    local name = UnitName("player") or "Unknown"
    local realm = self:GetRealm()
    local _, classFile = UnitClass("player")
    self.db.characters[key] = self.db.characters[key] or {}
    local c = self.db.characters[key]
    c.key = key
    c.name = name
    c.realm = realm
    c.displayName = name .. "-" .. realm
    c.class = classFile or c.class
    c.lastSeen = time()
    return key, c
end

function EL:RegisterModule(name, module)
    self.modules[name] = module
    module.name = name
    module.EL = self
end

function EL:ForEachModule(fn)
    for _, module in pairs(self.modules) do
        if module and module[fn] then
            pcall(module[fn], module)
        end
    end
end

function EL:MakeResourceKey(charKey, resourceKey)
    return charKey .. self.DB_KEY_SEP .. tostring(resourceKey or "default")
end

function EL:FormatDuration(seconds)
    seconds = tonumber(seconds) or 0
    if seconds <= 0 then return "Ready" end
    local days = math.floor(seconds / 86400)
    local hours = math.floor((seconds % 86400) / 3600)
    local mins = math.floor((seconds % 3600) / 60)
    if days > 0 then
        return string.format("%dd %dh", days, hours)
    elseif hours > 0 then
        return string.format("%dh %02dm", hours, mins)
    elseif mins > 0 then
        return string.format("%dm", mins)
    else
        return "<1m"
    end
end

function EL:GetClassColor(classFile)
    local c = classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile]
    if c then
        -- Slightly soften class colors so they fit the darker EmberLedger palette.
        local blend = 0.24
        local floor = 0.12
        local r = math.max(floor, (c.r or 1) * (1 - blend) + 0.68 * blend)
        local g = math.max(floor, (c.g or 1) * (1 - blend) + 0.70 * blend)
        local b = math.max(floor, (c.b or 1) * (1 - blend) + 0.76 * blend)
        return r, g, b
    end
    return 0.92, 0.92, 0.92
end

function EL:CharacterHasProfession(skillLineID)
    local professions = { GetProfessions() }
    for _, profIndex in ipairs(professions) do
        if profIndex then
            local _, _, _, _, _, _, skillLine = GetProfessionInfo(profIndex)
            if tonumber(skillLine) == tonumber(skillLineID) then
                return true
            end
        end
    end
    return false
end

function EL:GetCleanProfessionName(name)
    name = tostring(name or "")
    if name == "" then return "Profession" end
    local clean = name
    -- Store the full profession name internally, but keep the UI expansion-neutral.
    clean = clean:gsub("^Midnight%s+", "")
    clean = clean:gsub("^Khaz Algar%s+", "")
    clean = clean:gsub("^Dragon Isles%s+", "")
    clean = clean:gsub("^Shadowlands%s+", "")
    clean = clean:gsub("^Battle for Azeroth%s+", "")
    clean = clean:gsub("^Legion%s+", "")
    clean = clean:gsub("^Warlords%s+", "")
    clean = clean:gsub("^Pandaria%s+", "")
    clean = clean:gsub("^Cataclysm%s+", "")
    clean = clean:gsub("^Northrend%s+", "")
    clean = clean:gsub("^Outland%s+", "")
    clean = clean:gsub("^Classic%s+", "")
    clean = clean:gsub("^%s+", ""):gsub("%s+$", "")
    if clean == "" then clean = name end
    return clean
end

function EL:GetProfessionAbbreviation(data)
    if not data then return "N/A" end
    local clean = self:GetCleanProfessionName(data.professionName)
    local firstWord = clean:match("%a+") or clean
    local abbr = firstWord:sub(1, 4)
    if abbr == "" then abbr = "Prof" end
    return abbr:sub(1, 1):upper() .. abbr:sub(2):lower()
end

function EL:IsCharacterHidden(charKey)
    return self.db and self.db.settings and self.db.settings.hiddenCharacters and self.db.settings.hiddenCharacters[charKey] and true or false
end

function EL:SetCharacterHidden(charKey, hidden)
    if not charKey then return end
    self.db.settings.hiddenCharacters = self.db.settings.hiddenCharacters or {}
    self.db.settings.hiddenCharacters[charKey] = hidden and true or nil
end

function EL:RestoreHiddenCharacters()
    self.db.settings.hiddenCharacters = {}
    self:RequestUpdate()
    self:Print("Hidden characters restored.")
end

function EL:ResetCharacterData(charKey)
    if not (self.db and charKey) then return false end
    local char = self.db.characters and self.db.characters[charKey]
    local displayName = (char and (char.displayName or char.name)) or charKey

    if self.db.characters then
        self.db.characters[charKey] = nil
    end

    if self.db.resources then
        if self.db.resources.mulch then
            self.db.resources.mulch[charKey] = nil
        end
        if self.db.resources.concentration then
            for resourceKey, data in pairs(self.db.resources.concentration) do
                if data and data.charKey == charKey then
                    self.db.resources.concentration[resourceKey] = nil
                end
            end
        end
    end

    if self.db.settings and self.db.settings.hiddenCharacters then
        self.db.settings.hiddenCharacters[charKey] = nil
    end

    self:RequestUpdate()
    self:Print("Reset data for: " .. tostring(displayName))
    return true
end

function EL:GetConcentrationColor(quantity, maxQuantity)
    local threshold = self.db and self.db.settings and self.db.settings.alerts and tonumber(self.db.settings.alerts.concentrationThreshold)
    local maxQ = tonumber(maxQuantity) or self.CONCENTRATION_MAX_DEFAULT
    local target = threshold or maxQ
    target = math.max(1, math.min(maxQ > 0 and maxQ or self.CONCENTRATION_MAX_DEFAULT, target))
    local q = tonumber(quantity) or 0
    local pct = math.max(0, math.min(1, q / target))
    -- Dynamic gradient: red at 0, green at the configured alert threshold.
    if pct < 0.5 then
        local t = pct * 2
        return 0.95, 0.18 + (0.52 * t), 0.08
    end
    local t = (pct - 0.5) * 2
    return 0.95 * (1 - t) + 0.22 * t, 0.70 * (1 - t) + 1.00 * t, 0.08 * (1 - t) + 0.22 * t
end


function EL:GetMulchCountdownColor(remaining)
    if remaining == nil then return 0.7, 0.7, 0.7 end
    local duration = 3600
    local pct = 1 - math.max(0, math.min(1, (tonumber(remaining) or 0) / duration))
    -- Red when just used, amber during cooldown, green when ready.
    if pct < 0.5 then
        local t = pct * 2
        return 0.95, 0.18 + (0.52 * t), 0.08
    end
    local t = (pct - 0.5) * 2
    return 0.95 * (1 - t) + 0.22 * t, 0.70 * (1 - t) + 1.00 * t, 0.08 * (1 - t) + 0.22 * t
end

function EL:FormatCountdown(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
    if seconds <= 0 then return "Ready" end
    local days = math.floor(seconds / 86400)
    local hours = math.floor((seconds % 86400) / 3600)
    local mins = math.floor((seconds % 3600) / 60)
    local secs = seconds % 60
    if days > 0 then
        return string.format("%dd %dh", days, hours)
    elseif hours > 0 then
        return string.format("%dh %02dm", hours, mins)
    elseif mins > 0 then
        return string.format("%dm %02ds", mins, secs)
    else
        return string.format("%ds", secs)
    end
end

function EL:GetSortSettings()
    self.db.settings.sort = self.db.settings.sort or { key = "character", ascending = true }
    self.db.settings.sort.key = self.db.settings.sort.key or "character"
    if self.db.settings.sort.key == "full" then self.db.settings.sort.key = "character" end
    if self.db.settings.sort.ascending == nil then self.db.settings.sort.ascending = true end
    return self.db.settings.sort
end

function EL:SetSortKey(key)
    if not key then return end
    local sort = self:GetSortSettings()
    if sort.key == key then
        sort.ascending = not sort.ascending
    else
        sort.key = key
        sort.ascending = true
        if key == "conc" then sort.ascending = false end
    end
    self:RequestUpdate()
end

function EL:GetMulchSortValue(charKey, now)
    local data = self.db.resources.mulch and self.db.resources.mulch[charKey]
    if not self:HasImbuedMulchAccess(data) then return nil end
    return math.max(0, (tonumber(data.readyAt) or 0) - (now or time()))
end

function EL:GetDashboardSortValue(entry, key, now)
    if not entry then return nil end
    now = now or time()
    local charKey, char = entry.key, entry.char
    if not charKey then return nil end
    if key == "character" then
        return tostring((char and (char.displayName or char.name)) or charKey):lower()
    elseif key == "prof" then
        local conc = self:GetBestConcentrationForCharacter(charKey, now)
        return conc and self:GetProfessionAbbreviation(conc):lower() or nil
    elseif key == "conc" then
        local conc = self:GetBestConcentrationForCharacter(charKey, now)
        return conc and (self:GetEstimatedConcentration(conc, now) or 0) or nil
    elseif key == "full" then
        local conc = self:GetBestConcentrationForCharacter(charKey, now)
        if not conc then return nil end
        local maxQ = tonumber(conc.maxQuantity) or self.CONCENTRATION_MAX_DEFAULT
        local q = self:GetEstimatedConcentration(conc, now) or 0
        if q >= maxQ then return 0 end
        return math.ceil((maxQ - q) / self.CONCENTRATION_RATE_PER_HOUR * 3600)
    elseif key == "mulch" then
        return self:GetMulchSortValue(charKey, now)
    end
    return tostring((char and (char.displayName or char.name)) or charKey):lower()
end

function EL:SortDashboardRows(rows)
    if type(rows) ~= "table" then return end

    local sort = self:GetSortSettings()
    local key = sort.key or "character"
    local ascending = sort.ascending ~= false
    local now = time()
    local clean = {}

    local function isBadNumber(v)
        return type(v) == "number" and v ~= v
    end

    local function normalizeSortValue(v)
        if v == nil or isBadNumber(v) then
            return nil, nil
        end
        if type(v) == "number" then
            return "number", v
        end
        return "string", tostring(v):lower()
    end

    for i, entry in ipairs(rows) do
        if type(entry) == "table" and entry.key then
            local rawValue = self:GetDashboardSortValue(entry, key, now)
            local valueType, value = normalizeSortValue(rawValue)
            table.insert(clean, {
                row = entry,
                originalIndex = i,
                valueType = valueType,
                value = value,
                name = tostring((entry.char and (entry.char.displayName or entry.char.name)) or entry.key or ""):lower(),
                key = tostring(entry.key or ""),
            })
        end
    end

    table.sort(clean, function(a, b)
        -- Absolute safety. table.sort requires a strict weak ordering.
        if a == b then return false end
        if not a then return false end
        if not b then return true end

        local aNA = a.value == nil
        local bNA = b.value == nil

        -- Keep N/A values at the bottom in both directions.
        if aNA ~= bNA then
            return not aNA
        end

        -- Only compare the active sort value when both entries have one.
        if not aNA and not bNA then
            if a.valueType == b.valueType then
                if a.value ~= b.value then
                    if ascending then
                        return a.value < b.value
                    else
                        return b.value < a.value
                    end
                end
            else
                -- Deterministic fallback for mixed types. This should rarely happen,
                -- but avoids inconsistent comparisons if a column ever changes shape.
                if a.valueType ~= b.valueType then
                    return tostring(a.valueType or "") < tostring(b.valueType or "")
                end
            end
        end

        -- Tie breakers are always ascending and stable, regardless of selected direction.
        if a.name ~= b.name then return a.name < b.name end
        if a.key ~= b.key then return a.key < b.key end
        return (a.originalIndex or 0) < (b.originalIndex or 0)
    end)

    wipe(rows)
    for i, wrapped in ipairs(clean) do
        rows[i] = wrapped.row
    end
end

function EL:GetConcentrationEntriesForCharacter(charKey)
    local list = {}
    for _, data in pairs(self.db.resources.concentration or {}) do
        if data.charKey == charKey then
            table.insert(list, data)
        end
    end
    table.sort(list, function(a, b)
        local aa = self:GetProfessionAbbreviation(a)
        local bb = self:GetProfessionAbbreviation(b)
        if aa == bb then return tostring(a.professionName or "") < tostring(b.professionName or "") end
        return aa < bb
    end)
    return list
end

function EL:GetBestConcentrationForCharacter(charKey, now)
    local best
    now = now or time()
    for _, data in pairs(self.db.resources.concentration or {}) do
        if data.charKey == charKey then
            local qty = self:GetEstimatedConcentration(data, now)
            if not best or qty > (self:GetEstimatedConcentration(best, now) or 0) then
                best = data
            end
        end
    end
    return best
end

function EL:GetHighestConcentrationSummary()
    local best
    local now = time()
    for _, data in pairs(self.db.resources.concentration or {}) do
        if not self:IsCharacterHidden(data.charKey) then
        local char = self.db.characters[data.charKey or ""]
        local qty = self:GetEstimatedConcentration(data, now)
        if not best or qty > best.quantity then
            best = {
                charKey = data.charKey,
                displayName = (char and char.name) or data.charName or "Unknown",
                quantity = qty,
                maxQuantity = data.maxQuantity or self.CONCENTRATION_MAX_DEFAULT,
                professionName = data.professionName,
                professionID = data.professionID,
                abbrev = self:GetProfessionAbbreviation(data),
            }
        end
        end
    end
    return best
end


function EL:GetConcentrationReadyCount(threshold)
    threshold = tonumber(threshold) or 800
    local now = time()
    local seen = {}
    local count = 0
    for _, data in pairs(self.db.resources.concentration or {}) do
        local charKey = data and data.charKey
        if charKey and not seen[charKey] and not self:IsCharacterHidden(charKey) then
            local qty = self:GetEstimatedConcentration(data, now) or 0
            if qty >= threshold then
                seen[charKey] = true
                count = count + 1
            end
        end
    end
    return count
end

function EL:GetMulchReadyCount()
    local now = time()
    local seen = {}
    local count = 0
    for _, data in pairs(self.db.resources.mulch or {}) do
        local charKey = data and data.charKey
        if charKey and not seen[charKey] and not self:IsCharacterHidden(charKey) and self:HasImbuedMulchAccess(data) then
            local readyAt = tonumber(data.readyAt) or 0
            if readyAt <= now then
                seen[charKey] = true
                count = count + 1
            end
        end
    end
    return count
end

function EL:GetEstimatedConcentration(data, now)
    if not data then return nil end
    now = now or time()
    local maxQ = tonumber(data.maxQuantity) or self.CONCENTRATION_MAX_DEFAULT
    local q = tonumber(data.quantity) or 0
    local last = tonumber(data.lastUpdate) or now
    if q >= maxQ then return maxQ end
    local gained = math.floor(math.max(0, now - last) * (self.CONCENTRATION_RATE_PER_HOUR / 3600))
    return math.min(maxQ, q + gained)
end

function EL:GetConcentrationFullIn(data, now)
    if not data then return "N/A" end
    now = now or time()
    local maxQ = tonumber(data.maxQuantity) or self.CONCENTRATION_MAX_DEFAULT
    local q = self:GetEstimatedConcentration(data, now) or 0
    if q >= maxQ then return "Full" end
    local missing = maxQ - q
    local seconds = math.ceil(missing / self.CONCENTRATION_RATE_PER_HOUR * 3600)
    return self:FormatDuration(seconds)
end

function EL:HasImbuedMulchAccess(data)
    if type(data) ~= "table" then return false end
    -- v0.4.20: only trust the stricter confirmation written by Modules/Mulch.lua.
    -- Older saved values could mark generic Herbalism characters as mulch-ready.
    return data.confirmedImbuedMulchAccess == true and tonumber(data.confirmationVersion) == 2
end


function EL:CopperToSilver(copper)
    copper = tonumber(copper) or 0
    if copper <= 0 then return 0 end
    return math.floor((copper + 50) / 100)
end

function EL:FormatMoneyText(silver)
    silver = math.max(0, math.floor(tonumber(silver) or 0))
    local gold = math.floor(silver / 100)
    local sil = silver % 100
    if gold >= 1000 then
        return string.format("%.1fk", gold / 1000)
    end
    return string.format("%dg %02ds", gold, sil)
end

function EL:IsAddOnLoaded(name)
    if C_AddOns and C_AddOns.IsAddOnLoaded then
        return C_AddOns.IsAddOnLoaded(name)
    elseif IsAddOnLoaded then
        return IsAddOnLoaded(name)
    end
    return false
end

function EL:GetAuctionatorUnitPriceSilver(itemID)
    if not itemID or not Auctionator then return 0 end
    if Auctionator.API and Auctionator.API.v1 and Auctionator.API.v1.GetAuctionPriceByItemID then
        local ok, copperPrice = pcall(Auctionator.API.v1.GetAuctionPriceByItemID, self.name or "EmberLedger", itemID)
        if ok and type(copperPrice) == "number" and copperPrice > 0 then
            return self:CopperToSilver(copperPrice)
        end
    end
    if Auctionator.Database and Auctionator.Database.GetPrice then
        local ok, dbCopperPrice = pcall(Auctionator.Database.GetPrice, Auctionator.Database, tostring(itemID))
        if ok and type(dbCopperPrice) == "number" and dbCopperPrice > 0 then
            return self:CopperToSilver(dbCopperPrice)
        end
    end
    return 0
end

function EL:GetTSMUnitPriceSilver(itemID)
    if not itemID or not TSM_API or type(TSM_API.GetCustomPriceValue) ~= "function" then return 0 end
    local copperPrice = TSM_API.GetCustomPriceValue("dbmarket", "i:" .. tostring(itemID))
    if type(copperPrice) == "number" and copperPrice > 0 then
        return self:CopperToSilver(copperPrice)
    end
    return 0
end

function EL:GetUnitPriceSilver(itemID)
    local source = self.db and self.db.settings and self.db.settings.session and self.db.settings.session.pricingSource or "Auctionator"
    if source == "TSM" then
        return self:GetTSMUnitPriceSilver(itemID)
    end
    return self:GetAuctionatorUnitPriceSilver(itemID)
end

function EL:GetPricingWarning()
    local source = self.db and self.db.settings and self.db.settings.session and self.db.settings.session.pricingSource or "Auctionator"
    if source == "TSM" then
        if not self:IsAddOnLoaded("TradeSkillMaster") then return "TSM missing" end
        if not TSM_API then return "TSM not ready" end
        return nil
    end
    if not self:IsAddOnLoaded("Auctionator") then return "Auctionator missing" end
    if not Auctionator or not Auctionator.API or not Auctionator.API.v1 then return "Auctionator not ready" end
    return nil
end

function EL:GetSessionDB()
    self.db.session = self.db.session or {}
    local s = self.db.session
    s.totalSilver = tonumber(s.totalSilver) or 0
    s.items = type(s.items) == "table" and s.items or {}
    s.recent = type(s.recent) == "table" and s.recent or {}
    s.pendingChatLoot = type(s.pendingChatLoot) == "table" and s.pendingChatLoot or {}
    s.lastBagCounts = type(s.lastBagCounts) == "table" and s.lastBagCounts or {}
    s.categoryTotals = type(s.categoryTotals) == "table" and s.categoryTotals or {}
    if s.isPaused == nil then s.isPaused = false end
    s.priorDuration = tonumber(s.priorDuration) or 0
    s.sessionStartUptime = tonumber(s.sessionStartUptime) or GetTime()
    return s
end

function EL:StartFreshSessionOnLogin()
    -- Runtime-only guard: reset once per login/reload, not every PLAYER_ENTERING_WORLD fire.
    if self.sessionResetThisLogin then return end
    self.sessionResetThisLogin = true

    self.db.session = {
        totalSilver = 0,
        items = {},
        recent = {},
        pendingChatLoot = {},
        lastBagCounts = {},
        categoryTotals = {},
        isPaused = false,
        priorDuration = 0,
        sessionStartUptime = GetTime(),
        bagBaselineReady = false,
        baselinePrimingUntil = GetTime() + 5,
    }
end

function EL:AutoStartSessionOnLogin()
    self:StartFreshSessionOnLogin()
end

function EL:GetSessionElapsedSeconds()
    local s = self:GetSessionDB()
    local prior = tonumber(s.priorDuration) or 0
    if s.isPaused then return math.max(1, prior) end
    return math.max(1, prior + math.max(0, math.floor(GetTime() - (tonumber(s.sessionStartUptime) or GetTime()))))
end

function EL:GetSessionGoldPerHour()
    local s = self:GetSessionDB()
    return math.floor(((tonumber(s.totalSilver) or 0) * 3600) / self:GetSessionElapsedSeconds())
end

function EL:SetSessionPaused(paused)
    local s = self:GetSessionDB()
    if paused and not s.isPaused then
        s.priorDuration = self:GetSessionElapsedSeconds()
        s.isPaused = true
    elseif not paused and s.isPaused then
        s.isPaused = false
        s.sessionStartUptime = GetTime()
        if self.CountSessionItemsInBags then
            s.lastBagCounts = self:CountSessionItemsInBags()
            s.bagBaselineReady = true
        end
    end
    self:RequestUpdate()
end

function EL:ToggleSessionPause()
    local s = self:GetSessionDB()
    self:SetSessionPaused(not s.isPaused)
end

function EL:ResetSession()
    self.db.session = {
        totalSilver = 0,
        items = {},
        recent = {},
        pendingChatLoot = {},
        lastBagCounts = {},
        categoryTotals = {},
        isPaused = false,
        priorDuration = 0,
        sessionStartUptime = GetTime(),
        bagBaselineReady = false,
        baselinePrimingUntil = GetTime() + 2,
    }
    self:RequestUpdate()
    self:Print("Session reset.")
end

function EL:GetTopSessionItems(limit)
    local s = self:GetSessionDB()
    local list = {}
    for itemID, entry in pairs(s.items or {}) do
        local numericID = tonumber((type(entry) == "table" and entry.itemID) or itemID) or itemID
        if self.IsSessionTrackedItem and self:IsSessionTrackedItem(numericID) then
            entry.itemID = entry.itemID or numericID
            table.insert(list, entry)
        end
    end
    table.sort(list, function(a, b)
        local av, bv = tonumber(a.silver) or 0, tonumber(b.silver) or 0
        if av ~= bv then return av > bv end
        local aq, bq = tonumber(a.qty) or 0, tonumber(b.qty) or 0
        if aq ~= bq then return aq > bq end
        return tostring(a.name or a.itemID or "") < tostring(b.name or b.itemID or "")
    end)
    local out = {}
    for i = 1, math.min(tonumber(limit) or 4, #list) do out[i] = list[i] end
    return out
end



function EL:GetSessionLootLog(limit)
    local s = self:GetSessionDB()
    local out = {}
    local max = tonumber(limit) or 50
    for _, entry in ipairs(s.recent or {}) do
        if type(entry) == "table" then
            local itemID = tonumber(entry.itemID)
            if not itemID or (self.IsSessionTrackedItem and self:IsSessionTrackedItem(itemID)) then
                out[#out + 1] = entry
                if #out >= max then break end
            end
        end
    end
    return out
end

function EL:GetNextMulchSummary()
    local best
    local now = time()
    for _, data in pairs(self.db.resources.mulch or {}) do
        if self:HasImbuedMulchAccess(data) and not self:IsCharacterHidden(data.charKey) then
            local readyAt = tonumber(data.readyAt) or 0
            local remain = math.max(0, readyAt - now)
            if not best or remain < best.remaining then
                local char = self.db.characters[data.charKey or ""]
                best = {
                    charKey = data.charKey,
                    displayName = (char and char.name) or data.charName or "Unknown",
                    remaining = remain,
                    readyAt = readyAt,
                }
            end
        end
    end
    return best
end

function EL:GetCharacterRows()
    local rows = {}
    for key, char in pairs(self.db.characters or {}) do
        table.insert(rows, { key = key, char = char })
    end
    table.sort(rows, function(a, b)
        local an = (a.char and a.char.displayName) or a.key
        local bn = (b.char and b.char.displayName) or b.key
        return tostring(an):lower() < tostring(bn):lower()
    end)
    return rows
end

function EL:RequestUpdate()
    if self.UpdateButton then self:UpdateButton() end
    if self.RefreshPanel then self:RefreshPanel() end
    if self.RefreshSessionPanel then self:RefreshSessionPanel() end
    if self.RequestActionBarRefresh then self:RequestActionBarRefresh() end
end

function EL:Print(msg)
    print("|cffff7a1aEmberLedger:|r " .. tostring(msg))
end

SLASH_EMBERLEDGER1 = "/ember"
SLASH_EMBERLEDGER2 = "/emberledger"
SLASH_EMBERLEDGER3 = "/el"
SlashCmdList.EMBERLEDGER = function(msg)
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    local scaleValue = msg:match("^scale%s+([%d%.]+)$")
    if scaleValue then
        local scale = tonumber(scaleValue)
        if scale and scale >= 0.6 and scale <= 1.4 then
            EL.db.settings.panel.scale = scale
            if EL.ApplyPanelScale then EL:ApplyPanelScale() end
            EL:Print("Window scale set to " .. string.format("%.2f", scale) .. ".")
        else
            EL:Print("Use /el scale 0.6 through /el scale 1.4")
        end
    elseif msg == "scale" then
        local current = EL.db and EL.db.settings and EL.db.settings.panel and EL.db.settings.panel.scale or 1
        EL:Print("Current window scale: " .. string.format("%.2f", current) .. ". Use /el scale 0.85, /el scale 1, etc.")
    elseif msg == "reset" then
        if EL.ResetWindowPositions then EL:ResetWindowPositions() end
    elseif msg == "lock" or msg == "unlock" then
        EL.db.settings.lockWindows = (msg == "lock")
        if EL.RefreshSettingsPanel then EL:RefreshSettingsPanel() end
        EL:Print("Windows " .. (EL.db.settings.lockWindows and "locked. Hold Shift and drag to move them." or "unlocked."))
    elseif msg == "debug" then
        if EL.ToggleDebug then EL:ToggleDebug() end
    elseif msg == "refresh" then
        EL:ForEachModule("Refresh")
        EL:RequestUpdate()
        EL:Print("Refreshed.")
    elseif msg == "session start" or msg == "session resume" then
        EL:SetSessionPaused(false)
        EL:Print("Session tracking resumed.")
    elseif msg == "session pause" then
        EL:SetSessionPaused(true)
        EL:Print("Session tracking paused.")
    elseif msg == "session reset" then
        EL:ResetSession()
    elseif msg == "main" then
        if EL.ToggleMainPanel then EL:ToggleMainPanel() end
    elseif msg == "session" then
        if EL.ToggleSessionWindow then EL:ToggleSessionWindow() end
    elseif msg == "settings" or msg == "options" then
        if EL.ToggleSettingsPanel then EL:ToggleSettingsPanel() end
    elseif msg:match("^threshold%s+%d+$") then
        local value = tonumber(msg:match("^threshold%s+(%d+)$"))
        if value then
            EL.db.settings.alerts = EL.db.settings.alerts or {}
            EL.db.settings.alerts.concentrationThreshold = math.max(0, math.min(1000, value))
            EL:RequestUpdate()
            EL:Print("Concentration alert threshold set to " .. tostring(EL.db.settings.alerts.concentrationThreshold) .. ".")
        end
    elseif msg == "restore" or msg == "unhideall" then
        EL:RestoreHiddenCharacters()
    else
        if EL.TogglePanel then EL:TogglePanel() end
    end
end

EL.frame:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" then
        local loaded = ...
        if loaded ~= addonName then return end
        EL:EnsureDB()
        EL:GetCurrentCharacter()
        EL:ForEachModule("OnLoad")
        if EL.CreateUI then EL:CreateUI() end
        EL:ForEachModule("Refresh")
        EL:RequestUpdate()
    elseif event == "PLAYER_REGEN_ENABLED" then
        if EL.FlushCombatDeferredWork then EL:FlushCombatDeferredWork() end
    else
        for _, module in pairs(EL.modules) do
            if module and module.OnEvent then
                pcall(module.OnEvent, module, event, ...)
            end
        end
    end
end)

EL.frame:RegisterEvent("ADDON_LOADED")
EL.frame:RegisterEvent("PLAYER_ENTERING_WORLD")
EL.frame:RegisterEvent("TRADE_SKILL_SHOW")
EL.frame:RegisterEvent("TRADE_SKILL_DATA_SOURCE_CHANGED")
EL.frame:RegisterEvent("TRADE_SKILL_ITEM_CRAFTED_RESULT")
EL.frame:RegisterEvent("CURRENCY_DISPLAY_UPDATE")
EL.frame:RegisterEvent("BAG_UPDATE_DELAYED")
EL.frame:RegisterEvent("CHAT_MSG_LOOT")
EL.frame:RegisterEvent("PLAYER_REGEN_ENABLED")
